# GALANTE NEXUS OS — ESP32-S3 smartwatch prototype

Real ESP-IDF + FreeRTOS + LVGL firmware targeted at the **Waveshare ESP32-S3-Touch-LCD-2**. The board is an ESP32-S3R8 with 8 MB PSRAM, 16 MB Flash, 2-inch 240x320 ST7789T3 capacitive LCD/touch, QMI8658 IMU, 3.7 V MX1.25 battery interface, USB-C and TF card slot. The UI is rendered as **320x240 landscape**. Waveshare documents USB-C as the programming/debug interface. citeturn1view0

## Included in this prototype

- GALANTE / NEXUS boot screen
- Six native watch faces: Classic Premium, Moving Minimal, Digital Futuristic, Sport/Fitness, Science Fiction HUD and Gaming Theme
- Swipe left/right between watch faces; Watch Faces picker in Settings
- Animated analog hands, live time/date, battery and step data
- Smooth native LVGL page/game transitions where practical
- Home/app grid, Health, Fitness, Workout, Activity History, Sensors, Quick Settings and Settings
- MAX30102 HR + SpO2 input
- QMI8658 step counting
- Bluetooth LE HID media controls without a phone companion app
- Chess, Flappy Bird, 2048 and a lightweight native pseudo-3D racing game
- microSD and NVS settings/storage
- Brightness, screen timeout and low-power/sleep handling

## HR / SpO2 honesty

The health path does **not** generate placeholder readings. If the MAX30102 is missing, the UI says so. With no skin/finger contact, the UI shows `--`. During warm-up or poor signal quality it also shows `--` instead of guessing. A value is exposed only after timing/signal checks pass.

The algorithm is still a **prototype estimator, not a medical device**. MAX30102 placement, optical geometry, LED current, motion, skin contact and the specific sensor board all affect accuracy. Real hardware testing is required before trusting readings.

## Bluetooth limitation

The ESP32-S3 has Bluetooth 5 LE, not Bluetooth Classic. This firmware therefore uses BLE HID Consumer Control for direct Play/Pause, Next/Previous and volume-style controls. It does not pretend to have AVRCP track metadata; song title/artist information is not fabricated.

## Important hardware notes

The GPIO map in `main/board_pins.h` is intended for the Waveshare ESP32-S3-Touch-LCD-2. Verify the exact board revision/schematic before connecting external modules. The board's official documentation identifies the LCD as ST7789T3, touch as CST816D, IMU as QMI8658 and the battery connector as 3.7 V MX1.25. citeturn1view0

The prototype does not require a vibration motor, microphone, speaker, GPS or Android companion app.

## Build

Requires ESP-IDF 5.3 or newer.

```text
idf.py set-target esp32s3
idf.py build
idf.py -p PORT flash monitor
```

This source ZIP was **not compiled in this environment because ESP-IDF/toolchain is not installed here**. Therefore it should be treated as a prepared source project, not as a claimed hardware-tested binary.

## Android-only flashing

A PC is normally used to build the ESP-IDF project first. After a compiled firmware binary exists, Android USB-OTG flashers can write ESP32-S3 binaries. Current Android apps advertise ESP32-S3 USB/OTG flashing support, but they require the already-compiled binary files and correct flash offsets. citeturn3search0turn3search2

Waveshare's own flashing documentation uses USB programming and the BOOT/download mode when automatic entry fails. citeturn0search0
