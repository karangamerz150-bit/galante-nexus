#pragma once
void ui_init(void);
void ui_show_boot(void);
void ui_tick(void);              /* call once per LVGL loop iteration */
void ui_note_activity(void);     /* resets screen-timeout counter on touch */
bool ui_idle_timed_out(void);
void ui_enter_watchface(void);
