#pragma once
void ui_game_chess_open(lv_obj_t *parent);
void ui_game_flappy_open(lv_obj_t *parent);
void ui_game_2048_open(lv_obj_t *parent);
void ui_game_car_open(lv_obj_t *parent);
