/* GALANTE NEXUS OS - entry point.
 * Tasks:
 *   - LVGL runs its own task inside esp_lvgl_port (created by bsp_init()).
 *   - sensor_task: polls QMI8658 @ ~50Hz for the pedometer and pumps the
 *     MAX30102 FIFO for HR/SpO2 whenever the Health/Sensors screen has it
 *     running. Runs on core 1 so it never contends with LVGL rendering.
 *   - power_task: screen-timeout + brightness + deep-sleep policy.
 */
#include "bsp.h"
#include "board_pins.h"
#include "settings.h"
#include "qmi8658.h"
#include "steps.h"
#include "max30102.h"
#include "hr_spo2.h"
#include "ble_media.h"
#include "ui.h"
#include "esp_lvgl_port.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "main";

static void sensor_task(void *arg)
{
    qmi_init();
    hr_init();   /* probes MAX30102; HR sampling only runs when a screen calls hr_start() */
    while (1) {
        qmi_sample_t s;
        if (qmi_read(&s)) {
            uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
            steps_feed(s.ax, s.ay, s.az, now);
        }
        hr_task_tick();
        vTaskDelay(pdMS_TO_TICKS(10));   /* ~100Hz -- matches MAX30102 SpO2 config */
    }
}

static void power_task(void *arg)
{
    bool screen_on = true;
    while (1) {
        if (!ui_idle_timed_out() && !screen_on) { bsp_screen(true); screen_on = true; }
        else if (ui_idle_timed_out() && screen_on) { bsp_screen(false); screen_on = false; qmi_sleep(true); }
        else if (screen_on) qmi_sleep(false);

        static uint32_t save_ctr = 0;
        if (++save_ctr >= 100) { save_ctr = 0; steps_save_now(); settings_time_save(); }  /* persist every ~30s */
        vTaskDelay(pdMS_TO_TICKS(300));
    }
}

void app_main(void)
{
    ESP_LOGI(TAG, "GALANTE powered by NEXUS - booting");
    ESP_ERROR_CHECK(nvs_flash_init());

    settings_load();
    steps_init();
    settings_time_restore();   /* best-effort wall clock across reboots; no RTC chip on this board,
                                   so until the phone/BLE layer sets time, the clock free-runs from
                                   the last saved value -- shown as-is, never fabricated further. */

    bsp_init();
    bsp_backlight(g_set.brightness);

    if (g_set.ble_on) ble_media_init();

    lvgl_port_lock(0);
    ui_init();
    ui_show_boot();
    lvgl_port_unlock();

    xTaskCreatePinnedToCore(sensor_task, "sensors", 4096, NULL, 5, NULL, 1);
    xTaskCreatePinnedToCore(power_task, "power", 3072, NULL, 3, NULL, 1);

    vTaskDelay(pdMS_TO_TICKS(1400));
    lvgl_port_lock(0);
    ui_enter_watchface();
    lvgl_port_unlock();

    ESP_LOGI(TAG, "NEXUS OS running");
}
