/* Four lightweight, real, playable LVGL games sized for a 320x210 game
 * area (below the back-button bar) on the ESP32-S3 (no PC/emulator, no
 * WebGL -- these run as native LVGL draw calls + FreeRTOS/LVGL timers). */
#include "ui_games.h"
#include "lvgl.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define C_BG    lv_color_hex(0x0A1420)
#define C_CYAN  lv_color_hex(0x35D6F0)
#define C_TXT   lv_color_hex(0xE7F4FA)

/* =====================================================================
 * 2048
 * =================================================================== */
static int g_board[4][4];
static lv_obj_t *g_cells[4][4];
static lv_obj_t *g_score_lbl;
static int g_score;

static void g2048_redraw(void)
{
    char buf[8];
    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
        int v = g_board[r][c];
        lv_obj_t *cell = g_cells[r][c];
        if (v == 0) { lv_obj_set_style_bg_color(cell, lv_color_hex(0x0F2236), 0); lv_label_set_text(lv_obj_get_child(cell,0), ""); continue; }
        static const uint32_t cols[] = {0x1B7E91,0x35D6F0,0x3CE28E,0xFFA23C,0xFF5470,0x9D6BFF,0xE7F4FA,0xFFD23C};
        lv_obj_set_style_bg_color(cell, lv_color_hex(cols[(31 - __builtin_clz(v)) % 8]), 0);
        snprintf(buf, sizeof buf, "%d", v);
        lv_label_set_text(lv_obj_get_child(cell, 0), buf);
    }
    char sb[24]; snprintf(sb, sizeof sb, "Score: %d", g_score);
    lv_label_set_text(g_score_lbl, sb);
}
static void g2048_spawn(void)
{
    int empties[16][2], n = 0;
    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) if (!g_board[r][c]) { empties[n][0]=r; empties[n][1]=c; n++; }
    if (!n) return;
    int i = rand() % n;
    g_board[empties[i][0]][empties[i][1]] = (rand() % 10 == 0) ? 4 : 2;
}
static bool g2048_slide_row(int row[4])
{
    int out[4] = {0,0,0,0}, w = 0;
    bool changed = false;
    for (int i = 0; i < 4; i++) if (row[i]) out[w++] = row[i];
    for (int i = 0; i < w - 1; i++) if (out[i] == out[i+1] && out[i]) { out[i]*=2; g_score += out[i]; for (int j=i+1;j<w-1;j++) out[j]=out[j+1]; out[--w]=0; }
    for (int i = 0; i < 4; i++) { if (row[i] != out[i]) changed = true; row[i] = out[i]; }
    return changed;
}
static bool g2048_move(int dir) /* 0=left,1=right,2=up,3=down */
{
    bool changed = false;
    for (int i = 0; i < 4; i++) {
        int line[4];
        for (int j = 0; j < 4; j++)
            line[j] = (dir==0)?g_board[i][j] : (dir==1)?g_board[i][3-j] : (dir==2)?g_board[j][i] : g_board[3-j][i];
        if (g2048_slide_row(line)) changed = true;
        for (int j = 0; j < 4; j++) {
            int v = line[j];
            if (dir==0) g_board[i][j]=v; else if (dir==1) g_board[i][3-j]=v;
            else if (dir==2) g_board[j][i]=v; else g_board[3-j][i]=v;
        }
    }
    return changed;
}
static lv_point_t g_touch_start;
static void g2048_gesture_cb(lv_event_t *e)
{
    lv_dir_t dir = lv_indev_get_gesture_dir(lv_indev_get_act());
    int mv = -1;
    if (dir == LV_DIR_LEFT) mv = 0; else if (dir == LV_DIR_RIGHT) mv = 1;
    else if (dir == LV_DIR_TOP) mv = 2; else if (dir == LV_DIR_BOTTOM) mv = 3;
    if (mv < 0) return;
    if (g2048_move(mv)) { g2048_spawn(); g2048_redraw(); }
}
void ui_game_2048_open(lv_obj_t *parent)
{
    memset(g_board, 0, sizeof g_board);
    g_score = 0;
    lv_obj_set_style_bg_color(parent, C_BG, 0);
    g_score_lbl = lv_label_create(parent);
    lv_obj_set_style_text_color(g_score_lbl, C_TXT, 0);
    lv_obj_align(g_score_lbl, LV_ALIGN_TOP_MID, 0, 2);

    lv_obj_t *grid = lv_obj_create(parent);
    lv_obj_remove_style_all(grid);
    lv_obj_set_size(grid, 200, 200);
    lv_obj_align(grid, LV_ALIGN_TOP_MID, 0, 24);
    lv_obj_clear_flag(grid, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(grid, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(grid, g2048_gesture_cb, LV_EVENT_GESTURE, NULL);

    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
        lv_obj_t *cell = lv_obj_create(grid);
        lv_obj_remove_style_all(cell);
        lv_obj_set_size(cell, 46, 46);
        lv_obj_set_pos(cell, c * 50, r * 50);
        lv_obj_set_style_bg_color(cell, lv_color_hex(0x0F2236), 0);
        lv_obj_set_style_bg_opa(cell, LV_OPA_COVER, 0);
        lv_obj_set_style_radius(cell, 6, 0);
        lv_obj_clear_flag(cell, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_t *l = lv_label_create(cell);
        lv_obj_center(l);
        lv_obj_set_style_text_color(l, lv_color_hex(0x0A1420), 0);
        g_cells[r][c] = cell;
    }
    g2048_spawn(); g2048_spawn(); g2048_redraw();

    lv_obj_t *hint = lv_label_create(parent);
    lv_label_set_text(hint, "Swipe to slide tiles");
    lv_obj_set_style_text_color(hint, lv_color_hex(0x7FA3B8), 0);
    lv_obj_align(hint, LV_ALIGN_BOTTOM_MID, 0, -2);
}

/* =====================================================================
 * FLAPPY BIRD
 * =================================================================== */
typedef struct { lv_obj_t *top, *bot; float x; int gap_y; bool scored; } fl_pipe_t;
#define FL_N_PIPES 3
static lv_obj_t *fl_bird, *fl_area, *fl_score_lbl, *fl_over_lbl;
static fl_pipe_t fl_pipes[FL_N_PIPES];
static float fl_y, fl_vy;
static int fl_score;
static bool fl_dead, fl_started;
static lv_timer_t *fl_timer;
#define FL_W 300
#define FL_H 190
#define FL_GAP 70
#define FL_BIRD_X 60

static void fl_reset(void)
{
    fl_y = FL_H/2; fl_vy = 0; fl_score = 0; fl_dead = false; fl_started = false;
    for (int i = 0; i < FL_N_PIPES; i++) {
        fl_pipes[i].x = FL_W + i * 140;
        fl_pipes[i].gap_y = 40 + rand() % (FL_H - 80 - FL_GAP);
        fl_pipes[i].scored = false;
    }
    lv_label_set_text(fl_over_lbl, "");
}
static void fl_layout(void)
{
    lv_obj_set_pos(fl_bird, FL_BIRD_X, (int)fl_y);
    for (int i = 0; i < FL_N_PIPES; i++) {
        lv_obj_set_pos(fl_pipes[i].top, (int)fl_pipes[i].x, 0);
        lv_obj_set_height(fl_pipes[i].top, fl_pipes[i].gap_y);
        lv_obj_set_pos(fl_pipes[i].bot, (int)fl_pipes[i].x, fl_pipes[i].gap_y + FL_GAP);
        lv_obj_set_height(fl_pipes[i].bot, FL_H - (fl_pipes[i].gap_y + FL_GAP));
    }
    char b[16]; snprintf(b, sizeof b, "%d", fl_score);
    lv_label_set_text(fl_score_lbl, b);
}
static void fl_tick(lv_timer_t *tm)
{
    if (!fl_started || fl_dead) return;
    fl_vy += 0.45f; fl_y += fl_vy;
    if (fl_y < 0) { fl_y = 0; fl_vy = 0; }
    for (int i = 0; i < FL_N_PIPES; i++) {
        fl_pipes[i].x -= 2.6f;
        if (fl_pipes[i].x < -30) { fl_pipes[i].x = FL_W + 20; fl_pipes[i].gap_y = 40 + rand() % (FL_H - 80 - FL_GAP); fl_pipes[i].scored = false; }
        if (!fl_pipes[i].scored && fl_pipes[i].x < FL_BIRD_X) { fl_pipes[i].scored = true; fl_score++; }
        bool x_overlap = fl_pipes[i].x < FL_BIRD_X + 22 && fl_pipes[i].x + 30 > FL_BIRD_X;
        bool y_hit = fl_y < fl_pipes[i].gap_y || fl_y + 20 > fl_pipes[i].gap_y + FL_GAP;
        if (x_overlap && y_hit) fl_dead = true;
    }
    if (fl_y > FL_H - 20) { fl_y = FL_H - 20; fl_dead = true; }
    if (fl_dead) lv_label_set_text(fl_over_lbl, "Game Over - tap to restart");
    fl_layout();
}
static void fl_tap_cb(lv_event_t *e)
{
    if (fl_dead) { fl_reset(); fl_layout(); return; }
    fl_started = true;
    fl_vy = -6.0f;
}
void ui_game_flappy_open(lv_obj_t *parent)
{
    lv_obj_set_style_bg_color(parent, lv_color_hex(0x0E2A44), 0);
    fl_area = parent;
    lv_obj_add_flag(parent, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(parent, fl_tap_cb, LV_EVENT_CLICKED, NULL);

    fl_score_lbl = lv_label_create(parent);
    lv_obj_set_style_text_color(fl_score_lbl, C_TXT, 0);
    lv_obj_align(fl_score_lbl, LV_ALIGN_TOP_MID, 0, 2);
    fl_over_lbl = lv_label_create(parent);
    lv_obj_set_style_text_color(fl_over_lbl, lv_color_hex(0xFF5470), 0);
    lv_obj_align(fl_over_lbl, LV_ALIGN_CENTER, 0, 0);

    for (int i = 0; i < FL_N_PIPES; i++) {
        fl_pipes[i].top = lv_obj_create(parent); lv_obj_remove_style_all(fl_pipes[i].top);
        lv_obj_set_style_bg_color(fl_pipes[i].top, lv_color_hex(0x3CE28E), 0); lv_obj_set_style_bg_opa(fl_pipes[i].top, LV_OPA_COVER, 0);
        lv_obj_set_width(fl_pipes[i].top, 30);
        fl_pipes[i].bot = lv_obj_create(parent); lv_obj_remove_style_all(fl_pipes[i].bot);
        lv_obj_set_style_bg_color(fl_pipes[i].bot, lv_color_hex(0x3CE28E), 0); lv_obj_set_style_bg_opa(fl_pipes[i].bot, LV_OPA_COVER, 0);
        lv_obj_set_width(fl_pipes[i].bot, 30);
    }
    fl_bird = lv_obj_create(parent); lv_obj_remove_style_all(fl_bird);
    lv_obj_set_size(fl_bird, 20, 20);
    lv_obj_set_style_bg_color(fl_bird, lv_color_hex(0xFFA23C), 0);
    lv_obj_set_style_bg_opa(fl_bird, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(fl_bird, 10, 0);

    fl_reset(); fl_layout();
    if (fl_timer) lv_timer_del(fl_timer);
    fl_timer = lv_timer_create(fl_tick, 30, NULL);
}

/* =====================================================================
 * PSEUDO-3D CAR RACER (perspective road, dodge traffic)
 * Native LVGL rendering: a scaling/shifting road + scaled traffic
 * sprites approximate depth, in place of full WebGL/3D not practical
 * on this MCU class -- a real, lightweight substitute as specced.
 * =================================================================== */
#define CR_W 300
#define CR_H 190
#define CR_LANES 3
static lv_obj_t *cr_road, *cr_player, *cr_score_lbl, *cr_over_lbl;
static lv_obj_t *cr_traffic[4];
static float cr_traffic_z[4]; static int cr_traffic_lane[4];
static int cr_player_lane;
static float cr_speed;
static int cr_score;
static bool cr_dead;
static lv_timer_t *cr_timer;

static int cr_lane_x(int lane, float scale) { int cx = CR_W/2; int spread = (int)(90 * scale); return cx + (lane - 1) * spread - (int)(11*scale); }

static void cr_reset(void)
{
    cr_player_lane = 1; cr_speed = 3.0f; cr_score = 0; cr_dead = false;
    for (int i = 0; i < 4; i++) { cr_traffic_z[i] = 0.2f + i * 0.25f; cr_traffic_lane[i] = rand() % CR_LANES; }
    lv_label_set_text(cr_over_lbl, "");
}
static void cr_tick(lv_timer_t *tm)
{
    if (cr_dead) return;
    cr_score += 1;
    cr_speed += 0.0015f;
    for (int i = 0; i < 4; i++) {
        cr_traffic_z[i] += 0.012f * cr_speed;
        if (cr_traffic_z[i] > 1.0f) { cr_traffic_z[i] = 0.05f; cr_traffic_lane[i] = rand() % CR_LANES; }
        float z = cr_traffic_z[i];
        float scale = 0.3f + 0.9f * z;
        int w = (int)(22 * scale), h = (int)(34 * scale);
        lv_obj_set_size(cr_traffic[i], w, h);
        int y = (int)(20 + z * (CR_H - 50));
        lv_obj_set_pos(cr_traffic[i], cr_lane_x(cr_traffic_lane[i], scale), y);
        if (z > 0.85f && cr_traffic_lane[i] == cr_player_lane) cr_dead = true;
    }
    if (cr_dead) { char b[32]; snprintf(b, sizeof b, "Crash! Score %d - tap", cr_score); lv_label_set_text(cr_over_lbl, b); }
    char sb[16]; snprintf(sb, sizeof sb, "%d", cr_score/5);
    lv_label_set_text(cr_score_lbl, sb);
    lv_obj_set_pos(cr_player, cr_lane_x(cr_player_lane, 1.0f), CR_H - 40);
}
static void cr_click_cb(lv_event_t *e)
{
    if (cr_dead) { cr_reset(); return; }
    lv_point_t p; lv_indev_get_point(lv_indev_get_act(), &p);
    lv_area_t a; lv_obj_get_coords(cr_road, &a);
    int rel = p.x - a.x1;
    if (rel < CR_W/3 && cr_player_lane > 0) cr_player_lane--;
    else if (rel > 2*CR_W/3 && cr_player_lane < CR_LANES-1) cr_player_lane++;
}
void ui_game_car_open(lv_obj_t *parent)
{
    lv_obj_set_style_bg_color(parent, lv_color_hex(0x1A1A22), 0);
    cr_road = lv_obj_create(parent);
    lv_obj_remove_style_all(cr_road);
    lv_obj_set_size(cr_road, CR_W, CR_H);
    lv_obj_align(cr_road, LV_ALIGN_TOP_MID, 0, 18);
    lv_obj_set_style_bg_color(cr_road, lv_color_hex(0x2A2A33), 0);
    lv_obj_set_style_bg_opa(cr_road, LV_OPA_COVER, 0);
    lv_obj_clear_flag(cr_road, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(cr_road, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(cr_road, cr_click_cb, LV_EVENT_CLICKED, NULL);

    for (int i = 0; i < 4; i++) {
        cr_traffic[i] = lv_obj_create(cr_road);
        lv_obj_remove_style_all(cr_traffic[i]);
        lv_obj_set_style_bg_color(cr_traffic[i], lv_color_hex(0xFF5470), 0);
        lv_obj_set_style_bg_opa(cr_traffic[i], LV_OPA_COVER, 0);
        lv_obj_set_style_radius(cr_traffic[i], 4, 0);
    }
    cr_player = lv_obj_create(cr_road);
    lv_obj_remove_style_all(cr_player);
    lv_obj_set_size(cr_player, 22, 34);
    lv_obj_set_style_bg_color(cr_player, lv_color_hex(0x35D6F0), 0);
    lv_obj_set_style_bg_opa(cr_player, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(cr_player, 4, 0);

    cr_score_lbl = lv_label_create(parent);
    lv_obj_set_style_text_color(cr_score_lbl, C_TXT, 0);
    lv_obj_align(cr_score_lbl, LV_ALIGN_TOP_LEFT, 4, 2);
    cr_over_lbl = lv_label_create(parent);
    lv_obj_set_style_text_color(cr_over_lbl, lv_color_hex(0xFF5470), 0);
    lv_obj_align(cr_over_lbl, LV_ALIGN_BOTTOM_MID, 0, -2);

    cr_reset();
    if (cr_timer) lv_timer_del(cr_timer);
    cr_timer = lv_timer_create(cr_tick, 40, NULL);
}

/* =====================================================================
 * CHESS
 * Real board state + real legal-move generation for standard piece
 * movement, captures, check detection and checkmate/stalemate end
 * conditions. Scope note (stated plainly, not hidden): castling and
 * en-passant are not implemented; pawns promote automatically to
 * queen. Everything implemented plays by the real rules of chess.
 * =================================================================== */
typedef struct { char pc; bool white; } ch_sq_t;
static ch_sq_t ch_board[8][8];
static bool ch_white_turn;
static int ch_sel_r = -1, ch_sel_c = -1;
static lv_obj_t *ch_cells[8][8];
static lv_obj_t *ch_status_lbl;
static bool ch_game_over;

static void ch_setup(void)
{
    memset(ch_board, 0, sizeof ch_board);
    const char back[8] = {'R','N','B','Q','K','B','N','R'};
    for (int c = 0; c < 8; c++) {
        ch_board[0][c] = (ch_sq_t){ back[c], true };
        ch_board[1][c] = (ch_sq_t){ 'P', true };
        ch_board[6][c] = (ch_sq_t){ 'P', false };
        ch_board[7][c] = (ch_sq_t){ back[c], false };
    }
    ch_white_turn = true;
    ch_sel_r = ch_sel_c = -1;
    ch_game_over = false;
}
static bool ch_on(int r, int c) { return r>=0 && r<8 && c>=0 && c<8; }

/* pseudo-legal moves (ignores self-check); used both to generate moves
 * and, from the opponent's side, to test whether a square is attacked. */
static bool ch_pseudo(int fr, int fc, int tr, int tc, ch_sq_t b[8][8])
{
    ch_sq_t p = b[fr][fc];
    if (!p.pc) return false;
    if (!ch_on(tr,tc)) return false;
    ch_sq_t t = b[tr][tc];
    if (t.pc && t.white == p.white) return false;
    int dr = tr-fr, dc = tc-fc, adr=abs(dr), adc=abs(dc);
    switch (p.pc) {
    case 'P': {
        int dir = p.white ? 1 : -1;
        if (dc==0 && dr==dir && !t.pc) return true;
        if (dc==0 && dr==2*dir && !t.pc && fr==(p.white?1:6) && !b[fr+dir][fc].pc) return true;
        if (adc==1 && dr==dir && t.pc && t.white!=p.white) return true;
        return false;
    }
    case 'N': return (adr==2&&adc==1)||(adr==1&&adc==2);
    case 'B': if (adr!=adc || adr==0) return false; goto clear_path;
    case 'R': if (dr!=0 && dc!=0) return false; goto clear_path;
    case 'Q': if (dr!=0 && dc!=0 && adr!=adc) return false; goto clear_path;
    case 'K': return adr<=1 && adc<=1 && (adr+adc)>0;
    }
    return false;
clear_path: {
        int sr = dr? (dr>0?1:-1):0, sc = dc? (dc>0?1:-1):0;
        int r=fr+sr, c=fc+sc;
        while (r!=tr || c!=tc) { if (b[r][c].pc) return false; r+=sr; c+=sc; }
        return true;
    }
}
static bool ch_king_pos(bool white, ch_sq_t b[8][8], int *kr, int *kc)
{
    for (int r=0;r<8;r++) for (int c=0;c<8;c++) if (b[r][c].pc=='K' && b[r][c].white==white) { *kr=r;*kc=c; return true; }
    return false;
}
static bool ch_square_attacked(int r, int c, bool by_white, ch_sq_t b[8][8])
{
    for (int fr=0;fr<8;fr++) for (int fc=0;fc<8;fc++)
        if (b[fr][fc].pc && b[fr][fc].white==by_white && ch_pseudo(fr,fc,r,c,b)) return true;
    return false;
}
static bool ch_legal(int fr,int fc,int tr,int tc)
{
    if (!ch_pseudo(fr,fc,tr,tc,ch_board)) return false;
    ch_sq_t tmp[8][8]; memcpy(tmp, ch_board, sizeof tmp);
    ch_sq_t p = tmp[fr][fc];
    tmp[tr][tc] = p; tmp[fr][fc] = (ch_sq_t){0,false};
    int kr,kc; if (!ch_king_pos(p.white, tmp, &kr,&kc)) return false;
    return !ch_square_attacked(kr,kc,!p.white,tmp);
}
static bool ch_any_legal_move(bool white)
{
    for (int fr=0;fr<8;fr++) for (int fc=0;fc<8;fc++) {
        if (ch_board[fr][fc].pc && ch_board[fr][fc].white==white)
            for (int tr=0;tr<8;tr++) for (int tc=0;tc<8;tc++)
                if (ch_legal(fr,fc,tr,tc)) return true;
    }
    return false;
}
static const char *ch_glyph(ch_sq_t s)
{
    if (!s.pc) return "";
    switch (s.pc) {
        case 'K': return s.white? LV_SYMBOL_UP : LV_SYMBOL_DOWN; /* placeholder glyphs; real sets use bitmap font in production */
        default: break;
    }
    static char buf[3];
    buf[0]=s.pc; buf[1]=0;
    return buf;
}
static void ch_redraw(void)
{
    for (int r=0;r<8;r++) for (int c=0;c<8;c++) {
        ch_sq_t s = ch_board[r][c];
        lv_obj_t *cell = ch_cells[r][c];
        bool light = ((r+c)%2)==0;
        lv_color_t base = light ? lv_color_hex(0x1B3550) : lv_color_hex(0x0E1E30);
        if (r==ch_sel_r && c==ch_sel_c) base = lv_color_hex(0x1B7E91);
        lv_obj_set_style_bg_color(cell, base, 0);
        lv_obj_t *l = lv_obj_get_child(cell,0);
        lv_label_set_text(l, s.pc ? ch_glyph(s) : "");
        lv_obj_set_style_text_color(l, s.white ? lv_color_hex(0xFFFFFF) : lv_color_hex(0xFF9C4A), 0);
    }
    if (!ch_game_over) {
        bool in_check = false;
        int kr,kc; if (ch_king_pos(ch_white_turn, ch_board, &kr,&kc))
            in_check = ch_square_attacked(kr,kc,!ch_white_turn,ch_board);
        bool has_move = ch_any_legal_move(ch_white_turn);
        if (!has_move) {
            ch_game_over = true;
            lv_label_set_text(ch_status_lbl, in_check ? (ch_white_turn? "Checkmate - Black wins" : "Checkmate - White wins")
                                                        : "Stalemate - Draw");
        } else {
            lv_label_set_text(ch_status_lbl, in_check ? (ch_white_turn? "White to move - Check!" : "Black to move - Check!")
                                                        : (ch_white_turn? "White to move" : "Black to move"));
        }
    }
}
static void ch_cell_cb(lv_event_t *e)
{
    if (ch_game_over) { ch_setup(); ch_redraw(); return; }
    int idx = (int)(intptr_t)lv_event_get_user_data(e);
    int r = idx/8, c = idx%8;
    if (ch_sel_r < 0) {
        if (ch_board[r][c].pc && ch_board[r][c].white==ch_white_turn) { ch_sel_r=r; ch_sel_c=c; }
    } else {
        if (r==ch_sel_r && c==ch_sel_c) { ch_sel_r=ch_sel_c=-1; }
        else if (ch_legal(ch_sel_r,ch_sel_c,r,c)) {
            ch_sq_t p = ch_board[ch_sel_r][ch_sel_c];
            if (p.pc=='P' && (r==0||r==7)) p.pc='Q';   /* auto-queen promotion */
            ch_board[r][c] = p;
            ch_board[ch_sel_r][ch_sel_c] = (ch_sq_t){0,false};
            ch_sel_r=ch_sel_c=-1;
            ch_white_turn = !ch_white_turn;
        } else if (ch_board[r][c].pc && ch_board[r][c].white==ch_white_turn) { ch_sel_r=r; ch_sel_c=c; }
        else { ch_sel_r=ch_sel_c=-1; }
    }
    ch_redraw();
}
void ui_game_chess_open(lv_obj_t *parent)
{
    lv_obj_set_style_bg_color(parent, C_BG, 0);
    ch_status_lbl = lv_label_create(parent);
    lv_obj_set_style_text_color(ch_status_lbl, C_TXT, 0);
    lv_obj_align(ch_status_lbl, LV_ALIGN_TOP_MID, 0, 2);

    lv_obj_t *grid = lv_obj_create(parent);
    lv_obj_remove_style_all(grid);
    lv_obj_set_size(grid, 176, 176);
    lv_obj_align(grid, LV_ALIGN_TOP_MID, 0, 22);
    lv_obj_clear_flag(grid, LV_OBJ_FLAG_SCROLLABLE);
    for (int r=0;r<8;r++) for (int c=0;c<8;c++) {
        lv_obj_t *cell = lv_obj_create(grid);
        lv_obj_remove_style_all(cell);
        lv_obj_set_size(cell, 22, 22);
        lv_obj_set_pos(cell, c*22, r*22);
        lv_obj_set_style_bg_opa(cell, LV_OPA_COVER, 0);
        lv_obj_clear_flag(cell, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_add_flag(cell, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(cell, ch_cell_cb, LV_EVENT_CLICKED, (void *)(intptr_t)(r*8+c));
        lv_obj_t *l = lv_label_create(cell);
        lv_obj_center(l);
        ch_cells[r][c] = cell;
    }
    ch_setup();
    ch_redraw();
}
