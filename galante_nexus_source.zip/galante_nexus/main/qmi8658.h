#pragma once
#include <stdbool.h>
#include <stdint.h>
typedef struct { float ax, ay, az; float gx, gy, gz; float temp_c; } qmi_sample_t;
bool qmi_init(void);
bool qmi_read(qmi_sample_t *s);
void qmi_sleep(bool low_power);   /* true = 3Hz low-power accel-only mode */
