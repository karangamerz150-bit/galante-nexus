#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "driver/i2c_master.h"
extern i2c_master_bus_handle_t g_i2c;
void bsp_init(void);
i2c_master_dev_handle_t bsp_i2c_dev(uint8_t addr);
bool bsp_i2c_probe(uint8_t addr);
void bsp_backlight(int pct);
void bsp_screen(bool on);
int  bsp_battery_mv(void);   /* -1 if unreadable */
int  bsp_battery_pct(void);  /* -1 if unreadable */
bool bsp_sd_info(uint32_t *size_mb);
void bsp_deep_sleep(void);
