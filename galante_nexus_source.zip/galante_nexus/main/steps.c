/* Real-time pedometer: high-pass filtered accel magnitude, adaptive
 * peak detector with refractory period + magnitude thresholds. This
 * is a standard consumer-pedometer approach (no fabricated counts). */
#include "steps.h"
#include "settings.h"
#include <math.h>
#include <string.h>
#include <time.h>

#define HIST_DAYS 7
static uint32_t s_today;
static uint32_t s_last_day;
static uint32_t s_hist[HIST_DAYS];
static float s_mag_lp = 1.0f;
static float s_mag_prev = 0;
static bool  s_rising = false;
static uint32_t s_last_step_ms = 0;

static uint32_t today_index(void)
{
    time_t t = time(NULL);
    struct tm tmv; localtime_r(&t, &tmv);
    return tmv.tm_yday;
}

void steps_init(void)
{
    nv_get_blob("steps_hist", s_hist, sizeof(s_hist));
    s_today = nv_get_u32("steps_today", 0);
    s_last_day = nv_get_u32("steps_day", today_index());
}

void steps_save_now(void)
{
    nv_set_u32("steps_today", s_today);
    nv_set_u32("steps_day", s_last_day);
    nv_set_blob("steps_hist", s_hist, sizeof(s_hist));
}

static void roll_day_if_needed(void)
{
    uint32_t d = today_index();
    if (d == s_last_day) return;
    memmove(&s_hist[1], &s_hist[0], sizeof(s_hist) - sizeof(s_hist[0]));
    s_hist[0] = s_today;
    s_today = 0;
    s_last_day = d;
    steps_save_now();
}

void steps_feed(float ax, float ay, float az, uint32_t now_ms)
{
    roll_day_if_needed();
    float mag = sqrtf(ax * ax + ay * ay + az * az);
    s_mag_lp = s_mag_lp * 0.9f + mag * 0.1f;         /* slow baseline (~gravity) */
    float dyn = mag - s_mag_lp;                       /* dynamic (motion) component */

    if (dyn > 0.15f && !s_rising && (now_ms - s_last_step_ms) > 300) {
        s_rising = true;
    } else if (dyn < -0.05f && s_rising) {
        s_rising = false;
        if (fabsf(dyn) > 0.1f) {
            s_today++;
            s_last_step_ms = now_ms;
        }
    }
    s_mag_prev = mag;
}

uint32_t steps_today(void) { return s_today; }

void steps_get_history(uint32_t *out, int n)
{
    if (n > 0) out[0] = s_today;
    for (int i = 1; i < n && i <= HIST_DAYS; i++) out[i] = s_hist[i - 1];
}
