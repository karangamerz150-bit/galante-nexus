/* GALANTE NEXUS: conservative MAX30102 HR/SpO2 estimator.
 *
 * IMPORTANT: this is a hobby/prototype estimator, not a medical device.
 * It never invents a value. A number is exposed only after contact, warm-up,
 * pulse timing and signal-quality checks pass. Otherwise the UI gets --.
 */
#include "hr_spo2.h"
#include "max30102.h"
#include <math.h>
#include <string.h>
#include <stdint.h>

#define MIN_IR_DC          5000.0f
#define MIN_IR_AC          25.0f
#define MIN_RED_AC         8.0f
#define MAX_IBI_MS         2000.0f
#define MIN_IBI_MS         300.0f
#define BEAT_WIN           6
#define WARMUP_SAMPLES     300       /* ~3 s at 100 Hz */
#define QUALITY_SAMPLES    40        /* require ~0.4 s of stable quality */

static bool s_running;
static hr_state_t s_state = HR_SENSOR_MISSING;
static float ir_dc, red_dc, ir_env, red_env;
static bool s_above;
static uint32_t s_sample_i;
static uint32_t s_last_beat_i;
static float s_ibi_ms[BEAT_WIN];
static int s_ibi_n;
static int s_bpm = -1, s_spo2 = -1;
static uint32_t s_warmup_samples;
static uint32_t s_quality_samples;

static void reset_measurement(void)
{
    s_above = false;
    s_last_beat_i = 0;
    s_ibi_n = 0;
    s_bpm = -1;
    s_spo2 = -1;
    s_warmup_samples = 0;
    s_quality_samples = 0;
    s_sample_i = 0;
    ir_dc = red_dc = 0;
    ir_env = red_env = 0;
}

void hr_init(void)
{
    if (!max30102_init()) s_state = HR_SENSOR_MISSING;
    else s_state = HR_NO_CONTACT;
    s_running = false;
    reset_measurement();
}

void hr_start(void)
{
    if (!max30102_is_ready()) {
        s_running = false;
        s_state = HR_SENSOR_MISSING;
        reset_measurement();
        return;
    }
    s_running = true;
    s_state = HR_WARMING_UP;
    reset_measurement();
    max30102_shutdown(false);
}

void hr_stop(void)
{
    s_running = false;
    s_state = max30102_is_ready() ? HR_NO_CONTACT : HR_SENSOR_MISSING;
    reset_measurement();
    max30102_shutdown(true);
}

hr_state_t hr_get(int *bpm, int *spo2)
{
    if (bpm) *bpm = s_bpm;
    if (spo2) *spo2 = s_spo2;
    return s_state;
}

void hr_task_tick(void)
{
    if (!s_running || !max30102_is_ready()) return;

    uint32_t ir, red;
    while (max30102_read(&ir, &red)) {
        s_sample_i++;

        if ((float)ir < MIN_IR_DC) {
            s_state = HR_NO_CONTACT;
            reset_measurement();
            ir_dc = (float)ir;
            red_dc = (float)red;
            continue;
        }

        if (ir_dc <= 1.0f) ir_dc = (float)ir;
        if (red_dc <= 1.0f) red_dc = (float)red;
        ir_dc = ir_dc * 0.985f + (float)ir * 0.015f;
        red_dc = red_dc * 0.985f + (float)red * 0.015f;

        float ir_ac = (float)ir - ir_dc;
        float red_ac = (float)red - red_dc;
        ir_env = ir_env * 0.94f + fabsf(ir_ac) * 0.06f;
        red_env = red_env * 0.94f + fabsf(red_ac) * 0.06f;

        if (s_state == HR_NO_CONTACT) {
            s_state = HR_WARMING_UP;
            s_warmup_samples = 0;
            s_quality_samples = 0;
        }
        if (s_warmup_samples < WARMUP_SAMPLES) {
            s_warmup_samples++;
            s_state = HR_WARMING_UP;
            continue;
        }

        bool signal_ok = ir_env >= MIN_IR_AC && red_env >= MIN_RED_AC;
        if (!signal_ok) {
            s_state = HR_MEASURING;
            s_quality_samples = 0;
            s_bpm = -1;
            s_spo2 = -1;
            continue;
        }
        if (s_quality_samples < QUALITY_SAMPLES) s_quality_samples++;
        s_state = HR_MEASURING;

        /* Adaptive rising-edge detector. The envelope provides a noise-resistant threshold. */
        float threshold = fmaxf(MIN_IR_AC * 0.8f, ir_env * 0.55f);
        bool above = ir_ac > threshold;
        if (above && !s_above) {
            if (s_last_beat_i != 0) {
                float ibi = (float)(s_sample_i - s_last_beat_i) * 10.0f;
                if (ibi >= MIN_IBI_MS && ibi <= MAX_IBI_MS) {
                    s_ibi_ms[s_ibi_n % BEAT_WIN] = ibi;
                    s_ibi_n++;
                }
            }
            s_last_beat_i = s_sample_i;
        }
        s_above = above;

        if (s_quality_samples >= QUALITY_SAMPLES && s_ibi_n >= 4) {
            int n = s_ibi_n < BEAT_WIN ? s_ibi_n : BEAT_WIN;
            float sum = 0, min_ibi = 99999, max_ibi = 0;
            for (int i=0;i<n;i++) {
                float x = s_ibi_ms[i];
                sum += x;
                if (x < min_ibi) min_ibi = x;
                if (x > max_ibi) max_ibi = x;
            }
            float avg = sum / (float)n;
            float stability = max_ibi / fmaxf(min_ibi, 1.0f);
            if (stability <= 1.35f) {
                int candidate_bpm = (int)(60000.0f / avg + 0.5f);

                /* Conservative physiological range for this prototype. */
                if (candidate_bpm >= 40 && candidate_bpm <= 180) {
                    float r = (red_env / fmaxf(red_dc, 1.0f)) /
                              (ir_env / fmaxf(ir_dc, 1.0f));
                    float candidate_spo2 = 110.0f - 25.0f * r;

                    /* Reject implausible/noisy ratios instead of inventing a value. */
                    if (candidate_spo2 >= 85.0f && candidate_spo2 <= 100.0f) {
                        s_bpm = candidate_bpm;
                        s_spo2 = (int)(candidate_spo2 + 0.5f);
                        s_state = HR_OK;
                    } else {
                        s_bpm = -1;
                        s_spo2 = -1;
                        s_state = HR_MEASURING;
                    }
                }
            }
        }
    }
}
