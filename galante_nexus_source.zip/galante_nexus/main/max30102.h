#pragma once
#include <stdbool.h>
#include <stdint.h>
bool max30102_init(void);
bool max30102_is_ready(void);
bool max30102_read(uint32_t *ir, uint32_t *red);
void max30102_shutdown(bool shut);
