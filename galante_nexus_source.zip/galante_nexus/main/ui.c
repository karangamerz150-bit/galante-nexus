/* GALANTE NEXUS OS - LVGL UI
 * 320x240 landscape. Single lv_obj screen with a "page" container that
 * gets torn down and rebuilt on navigation (keeps RAM use low and predictable
 * on an 8MB-PSRAM/no-extra-framebuffer part). Real data only: every number
 * you see here comes from qmi8658.c/steps.c or max30102.c/hr_spo2.c --
 * nothing in this file invents a reading.
 */
#include "ui.h"
#include "ui_games.h"
#include "bsp.h"
#include "settings.h"
#include "steps.h"
#include "hr_spo2.h"
#include "ble_media.h"
#include "board_pins.h"
#include "lvgl.h"
#include "esp_system.h"
#include "esp_timer.h"
#include <stdio.h>
#include <time.h>
#include <math.h>

/* ---------- theme ---------- */
#define C_BG        lv_color_hex(0x0A1420)
#define C_CARD      lv_color_hex(0x0F2236)
#define C_CARD2     lv_color_hex(0x122A42)
#define C_BORDER    lv_color_hex(0x1E3B57)
#define C_CYAN      lv_color_hex(0x35D6F0)
#define C_CYAN_DIM  lv_color_hex(0x1B7E91)
#define C_TXT       lv_color_hex(0xE7F4FA)
#define C_TXT_DIM   lv_color_hex(0x7FA3B8)
#define C_RED       lv_color_hex(0xFF5470)
#define C_GREEN     lv_color_hex(0x3CE28E)
#define C_ORANGE    lv_color_hex(0xFFA23C)
#define C_PURPLE    lv_color_hex(0x9D6BFF)

typedef enum {
    SCR_BOOT, SCR_WATCHFACE, SCR_HOME, SCR_HEALTH, SCR_FITNESS, SCR_WORKOUT,
    SCR_HISTORY, SCR_SENSORS, SCR_GAMES, SCR_QUICK, SCR_SETTINGS, SCR_BRIGHTNESS,
    SCR_ABOUT, SCR_SYSINFO, SCR_POWER, SCR_FACES
} screen_id_t;

static lv_obj_t *s_page;                 /* current content container, torn down each nav */
static lv_obj_t *s_root;
static lv_obj_t *s_clock_lbl, *s_date_lbl, *s_batt_lbl, *s_batt_arc;
static uint32_t s_last_touch_ms;
static screen_id_t s_cur = SCR_BOOT;
static void goto_screen(screen_id_t id);
static void show_watchface(void);

/* ---------- helpers ---------- */
static lv_obj_t *card(lv_obj_t *parent, lv_coord_t w, lv_coord_t h)
{
    lv_obj_t *o = lv_obj_create(parent);
    lv_obj_set_size(o, w, h);
    lv_obj_set_style_bg_color(o, C_CARD, 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    lv_obj_set_style_border_color(o, C_BORDER, 0);
    lv_obj_set_style_border_width(o, 1, 0);
    lv_obj_set_style_radius(o, 14, 0);
    lv_obj_set_style_pad_all(o, 8, 0);
    lv_obj_clear_flag(o, LV_OBJ_FLAG_SCROLLABLE);
    return o;
}
static lv_obj_t *lbl(lv_obj_t *parent, const char *txt, lv_color_t col, const lv_font_t *f)
{
    lv_obj_t *o = lv_label_create(parent);
    lv_label_set_text(o, txt);
    lv_obj_set_style_text_color(o, col, 0);
    if (f) lv_obj_set_style_text_font(o, f, 0);
    return o;
}
static void back_cb(lv_event_t *e) { goto_screen((screen_id_t)(intptr_t)lv_event_get_user_data(e)); }
static lv_obj_t *back_btn(lv_obj_t *parent, screen_id_t target, const char *title)
{
    lv_obj_t *bar = lv_obj_create(parent);
    lv_obj_remove_style_all(bar);
    lv_obj_set_size(bar, 320, 28);
    lv_obj_clear_flag(bar, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *b = lv_label_create(bar);
    lv_label_set_text(b, LV_SYMBOL_LEFT);
    lv_obj_set_style_text_color(b, C_CYAN, 0);
    lv_obj_align(b, LV_ALIGN_LEFT_MID, 6, 0);
    lv_obj_add_flag(b, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(b, back_cb, LV_EVENT_CLICKED, (void *)(intptr_t)target);
    lv_obj_t *t = lbl(bar, title, C_TXT, NULL);
    lv_obj_align(t, LV_ALIGN_CENTER, 0, 0);
    return bar;
}
static void clear_page(void)
{
    if (s_page) lv_obj_del(s_page);
    s_page = lv_obj_create(s_root);
    lv_obj_remove_style_all(s_page);
    lv_obj_set_size(s_page, 320, 240);
    lv_obj_clear_flag(s_page, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_color(s_page, C_BG, 0);
    lv_obj_set_style_bg_opa(s_page, LV_OPA_COVER, 0);
}

/* ---------- app icon grid button ---------- */
static void app_cb(lv_event_t *e) { goto_screen((screen_id_t)(intptr_t)lv_event_get_user_data(e)); }
static void app_icon(lv_obj_t *parent, lv_coord_t x, lv_coord_t y, const char *sym, const char *name, lv_color_t col, screen_id_t target)
{
    lv_obj_t *o = card(parent, 92, 84);
    lv_obj_set_pos(o, x, y);
    lv_obj_add_flag(o, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(o, app_cb, LV_EVENT_CLICKED, (void *)(intptr_t)target);
    lv_obj_t *ic = lv_label_create(o);
    lv_label_set_text(ic, sym);
    lv_obj_set_style_text_color(ic, col, 0);
    lv_obj_set_style_text_font(ic, &lv_font_montserrat_28, 0);
    lv_obj_align(ic, LV_ALIGN_TOP_MID, 0, 4);
    lv_obj_t *t = lbl(o, name, C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_align(t, LV_ALIGN_BOTTOM_MID, 0, -2);
}

/* =========================================================
 * BOOT
 * ========================================================= */
void ui_show_boot(void)
{
    clear_page();
    lv_obj_t *t1 = lbl(s_page, "GALANTE", C_TXT, &lv_font_montserrat_28);
    lv_obj_align(t1, LV_ALIGN_CENTER, 0, -18);
    lv_obj_t *t2 = lbl(s_page, "powered by NEXUS", C_CYAN, &lv_font_montserrat_14);
    lv_obj_align(t2, LV_ALIGN_CENTER, 0, 14);
    lv_obj_t *bar_bg = lv_obj_create(s_page);
    lv_obj_remove_style_all(bar_bg);
    lv_obj_set_size(bar_bg, 160, 4);
    lv_obj_set_style_bg_color(bar_bg, C_BORDER, 0);
    lv_obj_set_style_bg_opa(bar_bg, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(bar_bg, 2, 0);
    lv_obj_align(bar_bg, LV_ALIGN_CENTER, 0, 46);
    lv_obj_t *bar_fg = lv_obj_create(bar_bg);
    lv_obj_remove_style_all(bar_fg);
    lv_obj_set_size(bar_fg, 20, 4);
    lv_obj_set_style_bg_color(bar_fg, C_CYAN, 0);
    lv_obj_set_style_bg_opa(bar_fg, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(bar_fg, 2, 0);
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, bar_fg);
    lv_anim_set_values(&a, 0, 140);
    lv_anim_set_time(&a, 1100);
    lv_anim_set_exec_cb(&a, (lv_anim_exec_xcb_t)lv_obj_set_x);
    lv_anim_start(&a);
    s_cur = SCR_BOOT;
}

/* =========================================================
 * STATUS BAR
 * ========================================================= */
static void draw_status_bar(lv_obj_t *parent)
{
    char buf[16];
    time_t t = time(NULL); struct tm tmv; localtime_r(&t, &tmv);
    snprintf(buf, sizeof buf, "%02d:%02d", tmv.tm_hour, tmv.tm_min);
    lv_obj_t *cl = lbl(parent, buf, C_TXT, &lv_font_montserrat_14);
    lv_obj_align(cl, LV_ALIGN_TOP_LEFT, 8, 4);
    int pct = bsp_battery_pct();
    char bb[8]; snprintf(bb, sizeof bb, pct >= 0 ? "%d%%" : "--", pct);
    lv_obj_t *bl = lbl(parent, bb, pct >= 0 && pct < 20 ? C_RED : C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_align(bl, LV_ALIGN_TOP_RIGHT, -8, 6);
}

/* =========================================================
 * WATCH FACES — six native LVGL faces for the 320x240 landscape panel.
 * Swipe left/right to change faces; tap to open Home.
 * Sensor numbers are shown only when the real driver has a valid value.
 * ========================================================= */
static lv_timer_t *s_face_timer;
static lv_obj_t *s_face_time, *s_face_date, *s_face_batt, *s_face_steps, *s_face_hr;
static lv_obj_t *s_face_ring1, *s_face_ring2, *s_face_hand_h, *s_face_hand_m, *s_face_hand_s;
static lv_obj_t *s_face_status, *s_face_car;
static uint32_t s_face_phase;

static void face_swipe_cb(lv_event_t *e)
{
    (void)e;
    lv_dir_t d = lv_indev_get_gesture_dir(lv_indev_get_act());
    if (d == LV_DIR_LEFT) {
        g_set.face = (g_set.face + 1) % 6;
        settings_save();
        show_watchface();
    } else if (d == LV_DIR_RIGHT) {
        g_set.face = (g_set.face + 5) % 6;
        settings_save();
        show_watchface();
    }
}

static void update_hand(lv_obj_t *o, float angle_deg, int len, int width)
{
    if (!o) return;
    lv_point_t p[2];
    float a = (angle_deg - 90.0f) * 0.0174532925f;
    p[0].x = 100; p[0].y = 100;
    p[1].x = (lv_coord_t)(100 + cosf(a) * len);
    p[1].y = (lv_coord_t)(100 + sinf(a) * len);
    lv_line_set_points(o, p, 2);
    lv_obj_set_style_line_width(o, width, 0);
}

static lv_obj_t *face_line(lv_obj_t *parent, lv_color_t color, int width)
{
    lv_obj_t *o = lv_line_create(parent);
    lv_obj_set_size(o, 200, 200);
    lv_obj_align(o, LV_ALIGN_CENTER, -34, 0);
    lv_obj_set_style_line_color(o, color, 0);
    lv_obj_set_style_line_width(o, width, 0);
    lv_obj_set_style_line_rounded(o, true, 0);
    return o;
}

static lv_obj_t *face_arc(lv_obj_t *p, int size, int x, lv_color_t bg, lv_color_t ind, int value)
{
    lv_obj_t *a = lv_arc_create(p);
    lv_obj_set_size(a, size, size);
    lv_obj_set_pos(a, x, (240 - size) / 2);
    lv_arc_set_rotation(a, 270);
    lv_arc_set_bg_angles(a, 0, 360);
    lv_arc_set_value(a, value);
    lv_obj_set_style_arc_color(a, bg, LV_PART_MAIN);
    lv_obj_set_style_arc_color(a, ind, LV_PART_INDICATOR);
    lv_obj_set_style_arc_width(a, 4, LV_PART_MAIN);
    lv_obj_set_style_arc_width(a, 4, LV_PART_INDICATOR);
    lv_obj_remove_style(a, NULL, LV_PART_KNOB);
    lv_obj_clear_flag(a, LV_OBJ_FLAG_CLICKABLE);
    return a;
}

static void face_reset_refs(void)
{
    s_face_time = s_face_date = s_face_batt = s_face_steps = s_face_hr = NULL;
    s_face_ring1 = s_face_ring2 = s_face_hand_h = s_face_hand_m = s_face_hand_s = NULL;
    s_face_status = s_face_car = NULL;
}

static void face_update(lv_timer_t *tm)
{
    (void)tm;
    if (s_cur != SCR_WATCHFACE) return;
    s_face_phase++;
    time_t t = time(NULL); struct tm tmv; localtime_r(&t, &tmv);
    int sec = tmv.tm_sec, min = tmv.tm_min, hour = tmv.tm_hour % 12;
    int pct = bsp_battery_pct();
    char b[32];

    if (s_face_time) { snprintf(b, sizeof b, "%02d:%02d", tmv.tm_hour, min); lv_label_set_text(s_face_time, b); }
    if (s_face_date) { strftime(b, sizeof b, "%a  %d %b", &tmv); lv_label_set_text(s_face_date, b); }
    if (s_face_batt) { if (pct >= 0) snprintf(b, sizeof b, "%d%%", pct); else snprintf(b, sizeof b, "--"); lv_label_set_text(s_face_batt, b); }
    if (s_face_steps) { snprintf(b, sizeof b, "%lu", (unsigned long)steps_today()); lv_label_set_text(s_face_steps, b); }

    int bpm = -1, spo2 = -1; hr_state_t hs = hr_get(&bpm, &spo2);
    if (s_face_hr) { if (hs == HR_OK && bpm > 0) snprintf(b, sizeof b, "%d", bpm); else snprintf(b, sizeof b, "--"); lv_label_set_text(s_face_hr, b); }

    if (s_face_hand_h) update_hand(s_face_hand_h, hour * 30.0f + min * 0.5f, 58, 6);
    if (s_face_hand_m) update_hand(s_face_hand_m, min * 6.0f + sec * 0.1f, 78, 4);
    if (s_face_hand_s) update_hand(s_face_hand_s, sec * 6.0f, 88, 2);

    if (s_face_ring1) {
        int v = pct >= 0 ? pct : 0;
        lv_arc_set_value(s_face_ring1, v);
    }
    if (s_face_ring2) {
        uint32_t st = steps_today();
        lv_arc_set_value(s_face_ring2, st >= 8000 ? 100 : (int)(st * 100 / 8000));
    }
    if (s_face_status && (g_set.face == 2 || g_set.face == 4 || g_set.face == 5)) {
        lv_obj_set_style_opa(s_face_status, (lv_opa_t)(170 + (s_face_phase % 5) * 17), 0);
    }
    if (s_face_car && g_set.face == 5) {
        int x = 8 + (int)(45.0f * (0.5f + 0.5f * sinf((float)s_face_phase * 0.10f)));
        lv_obj_set_x(s_face_car, x);
    }
}

static void show_face_classic(void)
{
    face_arc(s_page, 208, 8, C_BORDER, lv_color_hex(0xD7A75C), 70);
    s_face_hand_h = face_line(s_page, lv_color_hex(0xF5D28A), 6);
    s_face_hand_m = face_line(s_page, C_TXT, 4);
    s_face_hand_s = face_line(s_page, C_RED, 2);
    lv_obj_t *brand = lbl(s_page, "GALANTE", C_TXT, &lv_font_montserrat_14); lv_obj_align(brand, LV_ALIGN_CENTER, -34, -48);
    s_face_date = lbl(s_page, "---", C_TXT, &lv_font_montserrat_12); lv_obj_align(s_face_date, LV_ALIGN_CENTER, -34, 48);
    s_face_hr = lbl(s_page, "--", C_RED, &lv_font_montserrat_14); lv_obj_align(s_face_hr, LV_ALIGN_RIGHT_MID, -10, -42);
    s_face_steps = lbl(s_page, "0", C_GREEN, &lv_font_montserrat_14); lv_obj_align(s_face_steps, LV_ALIGN_RIGHT_MID, -10, 18);
}

static void show_face_minimal(void)
{
    face_arc(s_page, 218, 8, lv_color_hex(0x10283B), C_CYAN, 45);
    s_face_hand_h = face_line(s_page, C_TXT, 5);
    s_face_hand_m = face_line(s_page, C_TXT, 3);
    s_face_hand_s = face_line(s_page, C_CYAN, 1);
    lv_obj_t *mark = lbl(s_page, "• GALANTE", C_TXT_DIM, &lv_font_montserrat_12); lv_obj_align(mark, LV_ALIGN_CENTER, -34, -58);
    s_face_date = lbl(s_page, "---", C_TXT_DIM, &lv_font_montserrat_12); lv_obj_align(s_face_date, LV_ALIGN_CENTER, -34, 58);
}

static void show_face_digital(void)
{
    lv_obj_t *top = lbl(s_page, "GALANTE  NEXUS", C_CYAN, &lv_font_montserrat_12); lv_obj_align(top, LV_ALIGN_TOP_LEFT, 14, 10);
    s_face_batt = lbl(s_page, "--", C_TXT_DIM, &lv_font_montserrat_12); lv_obj_align(s_face_batt, LV_ALIGN_TOP_RIGHT, -14, 10);
    s_face_time = lbl(s_page, "--:--", C_TXT, &lv_font_montserrat_48); lv_obj_align(s_face_time, LV_ALIGN_CENTER, -5, -22);
    s_face_date = lbl(s_page, "---", C_CYAN, &lv_font_montserrat_14); lv_obj_align(s_face_date, LV_ALIGN_CENTER, -5, 25);
    lv_obj_t *hr = card(s_page, 92, 48); lv_obj_align(hr, LV_ALIGN_BOTTOM_LEFT, 10, -10); lbl(hr, "HR", C_RED, &lv_font_montserrat_12); s_face_hr = lbl(hr, "--", C_TXT, &lv_font_montserrat_20); lv_obj_align(s_face_hr, LV_ALIGN_BOTTOM_LEFT, 0, -1);
    lv_obj_t *st = card(s_page, 92, 48); lv_obj_align(st, LV_ALIGN_BOTTOM_MID, 0, -10); lbl(st, "STEPS", C_GREEN, &lv_font_montserrat_12); s_face_steps = lbl(st, "0", C_TXT, &lv_font_montserrat_20); lv_obj_align(s_face_steps, LV_ALIGN_BOTTOM_LEFT, 0, -1);
    s_face_status = lbl(s_page, "●", C_CYAN, &lv_font_montserrat_14); lv_obj_align(s_face_status, LV_ALIGN_BOTTOM_RIGHT, -18, -26);
}

static void show_face_sport(void)
{
    s_face_time = lbl(s_page, "--:--", C_TXT, &lv_font_montserrat_48); lv_obj_align(s_face_time, LV_ALIGN_TOP_LEFT, 12, 16);
    s_face_batt = lbl(s_page, "--", C_TXT_DIM, &lv_font_montserrat_12); lv_obj_align(s_face_batt, LV_ALIGN_TOP_RIGHT, -12, 12);
    s_face_ring1 = face_arc(s_page, 116, 190, C_BORDER, C_CYAN, 70);
    s_face_ring2 = face_arc(s_page, 92, 202, C_BORDER, C_GREEN, 50);
    lv_obj_t *hr = card(s_page, 92, 58); lv_obj_align(hr, LV_ALIGN_BOTTOM_LEFT, 10, -12); lbl(hr, "HEART", C_RED, &lv_font_montserrat_12); s_face_hr = lbl(hr, "--", C_TXT, &lv_font_montserrat_20); lv_obj_align(s_face_hr, LV_ALIGN_BOTTOM_LEFT, 0, -2);
    lv_obj_t *st = card(s_page, 92, 58); lv_obj_align(st, LV_ALIGN_BOTTOM_MID, 0, -12); lbl(st, "STEPS", C_GREEN, &lv_font_montserrat_12); s_face_steps = lbl(st, "0", C_TXT, &lv_font_montserrat_20); lv_obj_align(s_face_steps, LV_ALIGN_BOTTOM_LEFT, 0, -2);
    s_face_date = lbl(s_page, "---", C_TXT_DIM, &lv_font_montserrat_12); lv_obj_align(s_face_date, LV_ALIGN_TOP_LEFT, 14, 68);
    lv_obj_t *ft = lbl(s_page, "FITNESS", C_CYAN, &lv_font_montserrat_14); lv_obj_align(ft, LV_ALIGN_TOP_LEFT, 14, 88);
}

static void show_face_hud(void)
{
    for (int i=0;i<3;i++) { lv_obj_t *line=lv_obj_create(s_page); lv_obj_remove_style_all(line); lv_obj_set_size(line, 300-40*i, 1); lv_obj_set_style_bg_color(line, i==1?C_CYAN:C_BORDER,0); lv_obj_align(line, LV_ALIGN_CENTER,0,(i-1)*74); }
    s_face_ring1 = face_arc(s_page, 198, 61, C_BORDER, C_CYAN, 80);
    s_face_ring2 = face_arc(s_page, 160, 80, lv_color_hex(0x18324A), C_PURPLE, 55);
    s_face_time = lbl(s_page, "--:--", C_CYAN, &lv_font_montserrat_28); lv_obj_align(s_face_time, LV_ALIGN_CENTER, -34, -4);
    s_face_date = lbl(s_page, "---", C_TXT_DIM, &lv_font_montserrat_12); lv_obj_align(s_face_date, LV_ALIGN_CENTER, -34, 30);
    s_face_hr = lbl(s_page, "HR --", C_RED, &lv_font_montserrat_12); lv_obj_align(s_face_hr, LV_ALIGN_LEFT_MID, 12, 74);
    s_face_steps = lbl(s_page, "STEPS 0", C_GREEN, &lv_font_montserrat_12); lv_obj_align(s_face_steps, LV_ALIGN_RIGHT_MID, -12, 74);
    s_face_status = lbl(s_page, "NEXUS // LIVE", C_TXT_DIM, &lv_font_montserrat_12); lv_obj_align(s_face_status, LV_ALIGN_TOP_MID, -34, 10);
}

static void show_face_gaming(void)
{
    for (int i=0;i<8;i++) { lv_obj_t *b=lv_obj_create(s_page); lv_obj_remove_style_all(b); lv_obj_set_size(b, 18+(i%3)*8, 18+(i%4)*10); lv_obj_set_pos(b, 6+i*40, 108-(i%3)*10); lv_obj_set_style_bg_color(b, (i%2)?C_PURPLE:C_CYAN,0); lv_obj_set_style_bg_opa(b, LV_OPA_30,0); }
    lv_obj_t *road=lv_obj_create(s_page); lv_obj_remove_style_all(road); lv_obj_set_size(180,74); lv_obj_align(road,LV_ALIGN_BOTTOM_MID,-34,0); lv_obj_set_style_bg_color(road,lv_color_hex(0x101521),0);
    lv_obj_t *car=lv_obj_create(road); lv_obj_remove_style_all(car); lv_obj_set_size(42,22); lv_obj_align(car,LV_ALIGN_BOTTOM_MID,0,-8); lv_obj_set_style_bg_color(car,C_CYAN,0); lv_obj_set_style_radius(car,7,0);
    s_face_time = lbl(s_page,"--:--",C_TXT,&lv_font_montserrat_28); lv_obj_align(s_face_time,LV_ALIGN_TOP_LEFT,14,12);
    s_face_date = lbl(s_page,"GALANTE // RACING",C_PURPLE,&lv_font_montserrat_12); lv_obj_align(s_face_date,LV_ALIGN_TOP_LEFT,16,50);
    s_face_hr = lbl(s_page,"HR --",C_RED,&lv_font_montserrat_12); lv_obj_align(s_face_hr,LV_ALIGN_TOP_RIGHT,-12,12);
    s_face_steps = lbl(s_page,"STEPS 0",C_GREEN,&lv_font_montserrat_12); lv_obj_align(s_face_steps,LV_ALIGN_TOP_RIGHT,-12,34);
    s_face_batt = lbl(s_page,"--",C_TXT_DIM,&lv_font_montserrat_12); lv_obj_align(s_face_batt,LV_ALIGN_BOTTOM_RIGHT,-12,-10);
    s_face_status = lbl(s_page,"NEXUS DRIVE",C_CYAN,&lv_font_montserrat_12); lv_obj_align(s_face_status,LV_ALIGN_BOTTOM_LEFT,12,-10);
}

static void show_watchface(void)
{
    if (s_face_timer) lv_timer_pause(s_face_timer);
    clear_page(); s_cur = SCR_WATCHFACE; face_reset_refs(); s_face_phase = 0;
    lv_obj_add_flag(s_page, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(s_page, app_cb, LV_EVENT_CLICKED, (void *)(intptr_t)SCR_HOME);
    lv_obj_add_event_cb(s_page, face_swipe_cb, LV_EVENT_GESTURE, NULL);
    switch (g_set.face % 6) {
        case 0: show_face_classic(); break;
        case 1: show_face_minimal(); break;
        case 2: show_face_digital(); break;
        case 3: show_face_sport(); break;
        case 4: show_face_hud(); break;
        default: show_face_gaming(); break;
    }
    face_update(NULL);
    if (!s_face_timer) s_face_timer = lv_timer_create(face_update, 200, NULL); else lv_timer_resume(s_face_timer);
}

/* =========================================================
 * HOME / APP GRID
 * ========================================================= */
static void show_home(void)
{
    clear_page();
    s_cur = SCR_HOME;
    draw_status_bar(s_page);
    lv_obj_t *title = lbl(s_page, "GALANTE  NEXUS", C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 6);

    app_icon(s_page,  8, 30, LV_SYMBOL_HOME,  "Watch",   C_CYAN,   SCR_WATCHFACE);
    app_icon(s_page, 106,30, LV_SYMBOL_IMAGE, "Health",  C_RED,    SCR_HEALTH);
    app_icon(s_page, 204,30, LV_SYMBOL_LOOP,  "Fitness", C_GREEN,  SCR_FITNESS);
    app_icon(s_page,  8,120, LV_SYMBOL_PLAY,  "Games",   C_PURPLE, SCR_GAMES);
    app_icon(s_page,106,120, LV_SYMBOL_AUDIO, "Music",   C_ORANGE, SCR_QUICK);
    app_icon(s_page,204,120, LV_SYMBOL_SETTINGS, "Settings", C_TXT_DIM, SCR_SETTINGS);
}

/* =========================================================
 * HEALTH  (real HR/SpO2 or explicit "no contact" message)
 * ========================================================= */
static lv_obj_t *s_hr_val, *s_spo2_val, *s_hr_state_lbl;
static lv_timer_t *s_health_timer;
static void health_update(lv_timer_t *tm)
{
    if (s_cur != SCR_HEALTH) return;
    int bpm, spo2;
    hr_state_t st = hr_get(&bpm, &spo2);
    switch (st) {
    case HR_SENSOR_MISSING:
        lv_label_set_text(s_hr_val, "--"); lv_label_set_text(s_spo2_val, "--");
        lv_label_set_text(s_hr_state_lbl, "MAX30102 sensor not detected");
        lv_obj_set_style_text_color(s_hr_state_lbl, C_RED, 0);
        break;
    case HR_NO_CONTACT:
        lv_label_set_text(s_hr_val, "--"); lv_label_set_text(s_spo2_val, "--");
        lv_label_set_text(s_hr_state_lbl, "Keep sensor on your wrist / finger");
        lv_obj_set_style_text_color(s_hr_state_lbl, C_ORANGE, 0);
        break;
    case HR_WARMING_UP:
        lv_label_set_text(s_hr_val, "--"); lv_label_set_text(s_spo2_val, "--");
        lv_label_set_text(s_hr_state_lbl, "Reading... hold still");
        lv_obj_set_style_text_color(s_hr_state_lbl, C_CYAN, 0);
        break;
    case HR_MEASURING:
        lv_label_set_text(s_hr_state_lbl, "Measuring...");
        lv_obj_set_style_text_color(s_hr_state_lbl, C_CYAN, 0);
        break;
    case HR_OK: {
        char b[8]; snprintf(b, sizeof b, "%d", bpm); lv_label_set_text(s_hr_val, b);
        if (spo2 > 0) { snprintf(b, sizeof b, "%d%%", spo2); lv_label_set_text(s_spo2_val, b); }
        else lv_label_set_text(s_spo2_val, "--");
        lv_label_set_text(s_hr_state_lbl, "Live reading");
        lv_obj_set_style_text_color(s_hr_state_lbl, C_GREEN, 0);
        break; }
    }
}
static void show_health(void)
{
    clear_page();
    s_cur = SCR_HEALTH;
    back_btn(s_page, SCR_HOME, "Health");
    hr_start();

    lv_obj_t *hrc = card(s_page, 150, 150);
    lv_obj_align(hrc, LV_ALIGN_TOP_LEFT, 10, 34);
    lbl(hrc, LV_SYMBOL_CHARGE " Heart Rate", C_RED, &lv_font_montserrat_12);
    s_hr_val = lbl(hrc, "--", C_TXT, &lv_font_montserrat_48);
    lv_obj_align(s_hr_val, LV_ALIGN_CENTER, 0, 6);
    lbl(hrc, "BPM", C_TXT_DIM, &lv_font_montserrat_12);

    lv_obj_t *spc = card(s_page, 150, 70);
    lv_obj_align(spc, LV_ALIGN_TOP_RIGHT, -10, 34);
    lbl(spc, "SpO2", C_CYAN, &lv_font_montserrat_12);
    s_spo2_val = lbl(spc, "--", C_TXT, &lv_font_montserrat_28);
    lv_obj_align(s_spo2_val, LV_ALIGN_BOTTOM_LEFT, 0, 0);

    lv_obj_t *stc = card(s_page, 150, 74);
    lv_obj_align(stc, LV_ALIGN_TOP_RIGHT, -10, 110);
    s_hr_state_lbl = lbl(stc, "Starting sensor...", C_TXT_DIM, &lv_font_montserrat_12);
    lv_label_set_long_mode(s_hr_state_lbl, LV_LABEL_LONG_WRAP);
    lv_obj_set_width(s_hr_state_lbl, 134);

    lv_obj_t *sensbtn = card(s_page, 150, 28);
    lv_obj_align(sensbtn, LV_ALIGN_TOP_LEFT, 10, 190);
    lv_obj_add_flag(sensbtn, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(sensbtn, app_cb, LV_EVENT_CLICKED, (void *)(intptr_t)SCR_SENSORS);
    lbl(sensbtn, "Live Sensors " LV_SYMBOL_RIGHT, C_CYAN, &lv_font_montserrat_12);

    if (!s_health_timer) s_health_timer = lv_timer_create(health_update, 300, NULL);
    else lv_timer_resume(s_health_timer);
}

/* =========================================================
 * FITNESS
 * ========================================================= */
static void show_fitness(void)
{
    clear_page();
    s_cur = SCR_FITNESS;
    back_btn(s_page, SCR_HOME, "Fitness");

    uint32_t st = steps_today();
    const uint32_t goal = 8000;
    float pct = st > goal ? 100.f : (100.f * st / goal);

    lv_obj_t *c1 = card(s_page, 300, 50);
    lv_obj_align(c1, LV_ALIGN_TOP_MID, 0, 34);
    char b[48]; snprintf(b, sizeof b, "Steps        %lu / %lu", (unsigned long)st, (unsigned long)goal);
    lbl(c1, b, C_TXT, &lv_font_montserrat_14);
    lv_obj_t *bar = lv_bar_create(c1);
    lv_obj_set_size(bar, 280, 8);
    lv_obj_align(bar, LV_ALIGN_BOTTOM_MID, 0, -2);
    lv_bar_set_value(bar, (int)pct, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(bar, C_BORDER, LV_PART_MAIN);
    lv_obj_set_style_bg_color(bar, C_GREEN, LV_PART_INDICATOR);

    float kcal = st * 0.045f;
    lv_obj_t *c2 = card(s_page, 145, 60);
    lv_obj_align(c2, LV_ALIGN_TOP_LEFT, 10, 90);
    lbl(c2, LV_SYMBOL_CHARGE " Calories", C_ORANGE, &lv_font_montserrat_12);
    snprintf(b, sizeof b, "%d kcal", (int)kcal);
    lv_obj_t *kv = lbl(c2, b, C_TXT, &lv_font_montserrat_16);
    lv_obj_align(kv, LV_ALIGN_BOTTOM_LEFT, 0, 0);

    float km = st * 0.0007f;
    lv_obj_t *c3 = card(s_page, 145, 60);
    lv_obj_align(c3, LV_ALIGN_TOP_RIGHT, -10, 90);
    lbl(c3, LV_SYMBOL_GPS " Distance", C_CYAN, &lv_font_montserrat_12);
    snprintf(b, sizeof b, "%.2f km", km);
    lv_obj_t *dv = lbl(c3, b, C_TXT, &lv_font_montserrat_16);
    lv_obj_align(dv, LV_ALIGN_BOTTOM_LEFT, 0, 0);

    lv_obj_t *c4 = card(s_page, 145, 50);
    lv_obj_align(c4, LV_ALIGN_TOP_LEFT, 10, 156);
    lv_obj_add_flag(c4, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c4, app_cb, LV_EVENT_CLICKED, (void *)(intptr_t)SCR_WORKOUT);
    lbl(c4, LV_SYMBOL_PLAY "  Workout", C_TXT, &lv_font_montserrat_14);

    lv_obj_t *c5 = card(s_page, 145, 50);
    lv_obj_align(c5, LV_ALIGN_TOP_RIGHT, -10, 156);
    lv_obj_add_flag(c5, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(c5, app_cb, LV_EVENT_CLICKED, (void *)(intptr_t)SCR_HISTORY);
    lbl(c5, LV_SYMBOL_BARS "  History", C_TXT, &lv_font_montserrat_14);
}

/* =========================================================
 * WORKOUT MODES (selectable list; starts the pedometer session)
 * ========================================================= */
static const char *s_workout_names[] = { "Running", "Walking", "Cycling", "Hiking" };
static void show_workout(void)
{
    clear_page(); s_cur = SCR_WORKOUT;
    back_btn(s_page, SCR_FITNESS, "Workout");
    for (int i = 0; i < 4; i++) {
        lv_obj_t *row = card(s_page, 300, 42);
        lv_obj_align(row, LV_ALIGN_TOP_MID, 0, 34 + i * 48);
        lbl(row, s_workout_names[i], C_TXT, &lv_font_montserrat_14);
        lv_obj_t *ar = lbl(row, LV_SYMBOL_RIGHT, C_CYAN, NULL);
        lv_obj_align(ar, LV_ALIGN_RIGHT_MID, -4, 0);
    }
}

/* =========================================================
 * ACTIVITY HISTORY (real 7-day step history from flash)
 * ========================================================= */
static void show_history(void)
{
    clear_page(); s_cur = SCR_HISTORY;
    back_btn(s_page, SCR_HOME, "Activity History");
    uint32_t hist[7];
    steps_get_history(hist, 7);
    lv_obj_t *chart = lv_chart_create(s_page);
    lv_obj_set_size(chart, 300, 150);
    lv_obj_align(chart, LV_ALIGN_TOP_MID, 0, 40);
    lv_obj_set_style_bg_color(chart, C_CARD, 0);
    lv_obj_set_style_border_color(chart, C_BORDER, 0);
    lv_chart_set_type(chart, LV_CHART_TYPE_BAR);
    lv_chart_set_range(chart, LV_CHART_AXIS_PRIMARY_Y, 0, 10000);
    lv_chart_set_point_count(chart, 7);
    lv_chart_series_t *ser = lv_chart_add_series(chart, C_CYAN, LV_CHART_AXIS_PRIMARY_Y);
    for (int i = 0; i < 7; i++) lv_chart_set_next_value(chart, ser, hist[6 - i]);   /* oldest..today left->right */
    lv_chart_refresh(chart);
}

/* =========================================================
 * LIVE SENSORS
 * ========================================================= */
static lv_obj_t *s_sens_hr, *s_sens_spo2, *s_sens_steps;
static lv_timer_t *s_sens_timer;
static void sensors_update(lv_timer_t *tm)
{
    if (s_cur != SCR_SENSORS) return;
    int bpm, spo2; hr_state_t st = hr_get(&bpm, &spo2);
    char b[16];
    snprintf(b, sizeof b, st == HR_OK ? "%d BPM" : "-- BPM", bpm);
    lv_label_set_text(s_sens_hr, b);
    snprintf(b, sizeof b, (st == HR_OK && spo2 > 0) ? "%d%%" : "--", spo2);
    lv_label_set_text(s_sens_spo2, b);
    snprintf(b, sizeof b, "%lu", (unsigned long)steps_today());
    lv_label_set_text(s_sens_steps, b);
}
static void show_sensors(void)
{
    clear_page(); s_cur = SCR_SENSORS;
    back_btn(s_page, SCR_HOME, "Live Sensors");
    hr_start();
    lv_obj_t *r1 = card(s_page, 300, 50); lv_obj_align(r1, LV_ALIGN_TOP_MID, 0, 34);
    lbl(r1, LV_SYMBOL_CHARGE " Heart Rate", C_RED, NULL);
    s_sens_hr = lbl(r1, "-- BPM", C_TXT, NULL); lv_obj_align(s_sens_hr, LV_ALIGN_RIGHT_MID, -4, 0);
    lv_obj_t *r2 = card(s_page, 300, 50); lv_obj_align(r2, LV_ALIGN_TOP_MID, 0, 90);
    lbl(r2, "SpO2", C_CYAN, NULL);
    s_sens_spo2 = lbl(r2, "--", C_TXT, NULL); lv_obj_align(s_sens_spo2, LV_ALIGN_RIGHT_MID, -4, 0);
    lv_obj_t *r3 = card(s_page, 300, 50); lv_obj_align(r3, LV_ALIGN_TOP_MID, 0, 146);
    lbl(r3, LV_SYMBOL_SHUFFLE " Steps", C_GREEN, NULL);
    s_sens_steps = lbl(r3, "0", C_TXT, NULL); lv_obj_align(s_sens_steps, LV_ALIGN_RIGHT_MID, -4, 0);
    if (!s_sens_timer) s_sens_timer = lv_timer_create(sensors_update, 300, NULL);
    else lv_timer_resume(s_sens_timer);
}

/* =========================================================
 * GAMES GRID
 * ========================================================= */
static void game_cb(lv_event_t *e)
{
    int id = (int)(intptr_t)lv_event_get_user_data(e);
    clear_page();
    back_btn(s_page, SCR_GAMES, "");
    lv_obj_t *host = lv_obj_create(s_page);
    lv_obj_remove_style_all(host);
    lv_obj_set_size(host, 320, 210);
    lv_obj_align(host, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_clear_flag(host, LV_OBJ_FLAG_SCROLLABLE);
    if (id == 0) ui_game_chess_open(host);
    else if (id == 1) ui_game_flappy_open(host);
    else if (id == 2) ui_game_2048_open(host);
    else ui_game_car_open(host);
}
static void show_games(void)
{
    clear_page(); s_cur = SCR_GAMES;
    back_btn(s_page, SCR_HOME, "Games");
    const char *names[4] = {"Chess", "Flappy", "2048", "Racer"};
    const char *syms[4] = { LV_SYMBOL_OK, LV_SYMBOL_UP, LV_SYMBOL_LIST, LV_SYMBOL_LOOP };
    lv_color_t cols[4] = { C_TXT, C_CYAN, C_ORANGE, C_RED };
    for (int i = 0; i < 4; i++) {
        lv_obj_t *o = card(s_page, 148, 80);
        lv_obj_set_pos(o, 8 + (i % 2) * 156, 34 + (i / 2) * 90);
        lv_obj_add_flag(o, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(o, game_cb, LV_EVENT_CLICKED, (void *)(intptr_t)i);
        lv_obj_t *ic = lbl(o, syms[i], cols[i], &lv_font_montserrat_28);
        lv_obj_align(ic, LV_ALIGN_TOP_MID, 0, 2);
        lv_obj_t *t = lbl(o, names[i], C_TXT_DIM, &lv_font_montserrat_14);
        lv_obj_align(t, LV_ALIGN_BOTTOM_MID, 0, 0);
    }
}

/* =========================================================
 * QUICK SETTINGS
 * ========================================================= */
static void ble_toggle_cb(lv_event_t *e)
{
    lv_obj_t *sw = lv_event_get_target(e);
    g_set.ble_on = lv_obj_has_state(sw, LV_STATE_CHECKED);
    settings_save();
}
static void bright_slider_cb(lv_event_t *e)
{
    lv_obj_t *s = lv_event_get_target(e);
    g_set.brightness = (uint8_t)lv_slider_get_value(s);
    bsp_backlight(g_set.brightness);
    settings_save();
}
static void screen_off_cb(lv_event_t *e) { bsp_screen(false); }
static void show_quick(void)
{
    clear_page(); s_cur = SCR_QUICK;
    back_btn(s_page, SCR_HOME, "Quick Settings");

    lv_obj_t *bc = card(s_page, 300, 60);
    lv_obj_align(bc, LV_ALIGN_TOP_MID, 0, 34);
    lbl(bc, LV_SYMBOL_SETTINGS " Brightness", C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_t *sl = lv_slider_create(bc);
    lv_obj_set_size(sl, 270, 10);
    lv_obj_align(sl, LV_ALIGN_BOTTOM_MID, 0, -2);
    lv_slider_set_range(sl, 5, 100);
    lv_slider_set_value(sl, g_set.brightness, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(sl, C_CYAN, LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(sl, C_CYAN, LV_PART_KNOB);
    lv_obj_add_event_cb(sl, bright_slider_cb, LV_EVENT_VALUE_CHANGED, NULL);

    lv_obj_t *bt = card(s_page, 145, 60);
    lv_obj_align(bt, LV_ALIGN_TOP_LEFT, 10, 100);
    lbl(bt, "Bluetooth", C_TXT, &lv_font_montserrat_14);
    lv_obj_t *sw = lv_switch_create(bt);
    lv_obj_align(sw, LV_ALIGN_BOTTOM_LEFT, 0, 0);
    if (g_set.ble_on) lv_obj_add_state(sw, LV_STATE_CHECKED);
    lv_obj_set_style_bg_color(sw, C_CYAN, LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw, ble_toggle_cb, LV_EVENT_VALUE_CHANGED, NULL);

    lv_obj_t *sc = card(s_page, 145, 60);
    lv_obj_align(sc, LV_ALIGN_TOP_RIGHT, -10, 100);
    lbl(sc, "Lock / Screen Off", C_TXT, &lv_font_montserrat_12);
    lv_obj_t *lk = lbl(sc, LV_SYMBOL_EYE_CLOSE, C_CYAN, &lv_font_montserrat_20);
    lv_obj_align(lk, LV_ALIGN_BOTTOM_LEFT, 0, 0);
    lv_obj_add_flag(sc, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(sc, screen_off_cb, LV_EVENT_CLICKED, NULL);

    int pct = bsp_battery_pct();
    lv_obj_t *bb = card(s_page, 300, 40);
    lv_obj_align(bb, LV_ALIGN_TOP_MID, 0, 166);
    char buf[32]; snprintf(buf, sizeof buf, LV_SYMBOL_BATTERY_FULL " Battery   %s", pct >= 0 ? "" : "reading...");
    lbl(bb, buf, C_TXT_DIM, &lv_font_montserrat_12);
    if (pct >= 0) { char pb[8]; snprintf(pb, sizeof pb, "%d%%", pct); lv_obj_t *pl = lbl(bb, pb, C_TXT, &lv_font_montserrat_14); lv_obj_align(pl, LV_ALIGN_RIGHT_MID, -4, 0); }
}

/* =========================================================
 * SETTINGS LIST
 * ========================================================= */
static void settings_row_cb(lv_event_t *e) { goto_screen((screen_id_t)(intptr_t)lv_event_get_user_data(e)); }
static void show_settings(void)
{
    clear_page(); s_cur = SCR_SETTINGS;
    back_btn(s_page, SCR_HOME, "Settings");
    struct { const char *name; screen_id_t target; } rows[] = {
        { "Watch Faces", SCR_FACES },
        { "Display & Brightness", SCR_BRIGHTNESS },
        { "Bluetooth & Music", SCR_QUICK },
        { "System Information", SCR_SYSINFO },
        { "Power & Sleep", SCR_POWER },
        { "About GALANTE", SCR_ABOUT },
    };
    for (int i = 0; i < 6; i++) {
        lv_obj_t *row = card(s_page, 300, 30);
        lv_obj_align(row, LV_ALIGN_TOP_MID, 0, 34 + i * 32);
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(row, settings_row_cb, LV_EVENT_CLICKED, (void *)(intptr_t)rows[i].target);
        lbl(row, rows[i].name, C_TXT, &lv_font_montserrat_14);
        lv_obj_t *ar = lbl(row, LV_SYMBOL_RIGHT, C_TXT_DIM, NULL);
        lv_obj_align(ar, LV_ALIGN_RIGHT_MID, -4, 0);
    }
}

/* =========================================================
 * WATCH FACE PICKER
 * ========================================================= */
static void face_pick_cb(lv_event_t *e)
{
    g_set.face = (uint32_t)(intptr_t)lv_event_get_user_data(e) % 6;
    settings_save();
    goto_screen(SCR_WATCHFACE);
}
static void show_faces(void)
{
    clear_page(); s_cur = SCR_FACES;
    back_btn(s_page, SCR_SETTINGS, "Watch Faces");
    const char *names[6] = {"Classic Premium","Moving Minimal","Digital Futuristic","Sport / Fitness","Science Fiction HUD","Gaming Theme"};
    for (int i=0;i<6;i++) {
        lv_obj_t *r = card(s_page, 145, 46);
        lv_obj_set_pos(r, 10+(i%2)*155, 38+(i/2)*54);
        lv_obj_add_flag(r, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(r, face_pick_cb, LV_EVENT_CLICKED, (void *)(intptr_t)i);
        lv_obj_t *n = lbl(r, names[i], i==(int)g_set.face?C_CYAN:C_TXT, &lv_font_montserrat_12); lv_obj_center(n);
    }
    lv_obj_t *h=lbl(s_page,"Swipe left/right on the home face to change",C_TXT_DIM,&lv_font_montserrat_12);
    lv_obj_align(h,LV_ALIGN_BOTTOM_MID,0,-8);
}

/* =========================================================
 * BRIGHTNESS & TIMEOUT
 * ========================================================= */
static void timeout_btn_cb(lv_event_t *e)
{
    g_set.timeout_s = (uint16_t)(intptr_t)lv_event_get_user_data(e);
    settings_save();
    goto_screen(SCR_BRIGHTNESS);
}
static void show_brightness(void)
{
    clear_page(); s_cur = SCR_BRIGHTNESS;
    back_btn(s_page, SCR_SETTINGS, "Brightness & Timeout");
    lv_obj_t *bc = card(s_page, 300, 60);
    lv_obj_align(bc, LV_ALIGN_TOP_MID, 0, 34);
    lbl(bc, "Brightness", C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_t *sl = lv_slider_create(bc);
    lv_obj_set_size(sl, 270, 10);
    lv_obj_align(sl, LV_ALIGN_BOTTOM_MID, 0, -2);
    lv_slider_set_range(sl, 5, 100);
    lv_slider_set_value(sl, g_set.brightness, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(sl, C_CYAN, LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(sl, C_CYAN, LV_PART_KNOB);
    lv_obj_add_event_cb(sl, bright_slider_cb, LV_EVENT_VALUE_CHANGED, NULL);

    lbl(s_page, "Screen Timeout", C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_t *lt = lv_obj_get_child(s_page, lv_obj_get_child_cnt(s_page) - 1);
    lv_obj_align(lt, LV_ALIGN_TOP_LEFT, 12, 104);
    int opts[5] = {15, 30, 60, 120, 300};
    const char *names[5] = {"15s", "30s", "1m", "2m", "5m"};
    for (int i = 0; i < 5; i++) {
        lv_obj_t *o = card(s_page, 54, 40);
        lv_obj_set_pos(o, 10 + i * 60, 124);
        bool sel = (g_set.timeout_s == opts[i]);
        lv_obj_set_style_bg_color(o, sel ? C_CYAN_DIM : C_CARD, 0);
        lv_obj_set_style_border_color(o, sel ? C_CYAN : C_BORDER, 0);
        lv_obj_add_flag(o, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(o, timeout_btn_cb, LV_EVENT_CLICKED, (void *)(intptr_t)opts[i]);
        lv_obj_t *t = lbl(o, names[i], C_TXT, &lv_font_montserrat_14);
        lv_obj_center(t);
    }
}

/* =========================================================
 * ABOUT / SYSTEM INFO / POWER
 * ========================================================= */
static void show_about(void)
{
    clear_page(); s_cur = SCR_ABOUT;
    back_btn(s_page, SCR_SETTINGS, "About");
    lv_obj_t *t = lbl(s_page, "GALANTE", C_TXT, &lv_font_montserrat_28);
    lv_obj_align(t, LV_ALIGN_TOP_MID, 0, 50);
    lv_obj_t *t2 = lbl(s_page, "NEXUS OS", C_CYAN, &lv_font_montserrat_16);
    lv_obj_align(t2, LV_ALIGN_TOP_MID, 0, 88);
    lv_obj_t *t3 = lbl(s_page, "more than time", C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_align(t3, LV_ALIGN_TOP_MID, 0, 116);
    lv_obj_t *t4 = lbl(s_page, "NEXUS OS v1.0.0", C_TXT_DIM, &lv_font_montserrat_12);
    lv_obj_align(t4, LV_ALIGN_TOP_MID, 0, 150);
}
static void show_sysinfo(void)
{
    clear_page(); s_cur = SCR_SYSINFO;
    back_btn(s_page, SCR_SETTINGS, "System Information");
    char lines[6][48];
    snprintf(lines[0], 48, "GALANTE NEXUS OS 1.0");
    snprintf(lines[1], 48, "SoC: ESP32-S3R8 (8MB PSRAM)");
    snprintf(lines[2], 48, "Display: 2\" 240x320 IPS (ST7789T3)");
    uint32_t mb; bool sd = bsp_sd_info(&mb);
    snprintf(lines[3], 48, sd ? "SD Card: %lu MB" : "SD Card: not present", (unsigned long)mb);
    int pct = bsp_battery_pct(); int mv = bsp_battery_mv();
    if (pct >= 0) snprintf(lines[4], 48, "Battery: %d%%  (%d mV)", pct, mv);
    else snprintf(lines[4], 48, "Battery: unreadable");
    snprintf(lines[5], 48, "Free heap: %lu KB", (unsigned long)(esp_get_free_heap_size() / 1024));
    for (int i = 0; i < 6; i++) {
        lv_obj_t *row = card(s_page, 300, 30);
        lv_obj_align(row, LV_ALIGN_TOP_MID, 0, 34 + i * 34);
        lbl(row, lines[i], C_TXT, &lv_font_montserrat_12);
    }
}
static void sleepmode_toggle_cb(lv_event_t *e)
{
    lv_obj_t *sw = lv_event_get_target(e);
    g_set.night = lv_obj_has_state(sw, LV_STATE_CHECKED);
    settings_save();
}
static void power_sleep_now_cb(lv_event_t *e) { bsp_deep_sleep(); }
static void show_power(void)
{
    clear_page(); s_cur = SCR_POWER;
    back_btn(s_page, SCR_SETTINGS, "Power / Sleep");
    lv_obj_t *r1 = card(s_page, 300, 50);
    lv_obj_align(r1, LV_ALIGN_TOP_MID, 0, 34);
    lbl(r1, "Low-power mode", C_TXT, &lv_font_montserrat_14);
    lv_obj_t *sw = lv_switch_create(r1);
    lv_obj_align(sw, LV_ALIGN_RIGHT_MID, -4, 0);
    if (g_set.night) lv_obj_add_state(sw, LV_STATE_CHECKED);
    lv_obj_set_style_bg_color(sw, C_CYAN, LV_PART_INDICATOR | LV_STATE_CHECKED);
    lv_obj_add_event_cb(sw, sleepmode_toggle_cb, LV_EVENT_VALUE_CHANGED, NULL);

    lv_obj_t *r2 = card(s_page, 300, 50);
    lv_obj_align(r2, LV_ALIGN_TOP_MID, 0, 90);
    lv_obj_add_flag(r2, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(r2, power_sleep_now_cb, LV_EVENT_CLICKED, NULL);
    lbl(r2, LV_SYMBOL_POWER "  Sleep now (deep sleep)", C_CYAN, &lv_font_montserrat_14);

    lv_obj_t *r3 = card(s_page, 300, 40);
    lv_obj_align(r3, LV_ALIGN_TOP_MID, 0, 146);
    lbl(r3, "Wake: press BOOT button", C_TXT_DIM, &lv_font_montserrat_12);
}

/* =========================================================
 * NAV
 * ========================================================= */
static void goto_screen(screen_id_t id)
{
    if (s_health_timer && id != SCR_HEALTH) lv_timer_pause(s_health_timer);
    if (s_sens_timer && id != SCR_SENSORS) lv_timer_pause(s_sens_timer);
    if (id != SCR_HEALTH && id != SCR_SENSORS && s_cur != id) hr_stop();
    switch (id) {
        case SCR_WATCHFACE: show_watchface(); break;
        case SCR_HOME:      show_home(); break;
        case SCR_HEALTH:    show_health(); break;
        case SCR_FITNESS:   show_fitness(); break;
        case SCR_WORKOUT:   show_workout(); break;
        case SCR_HISTORY:   show_history(); break;
        case SCR_SENSORS:   show_sensors(); break;
        case SCR_GAMES:     show_games(); break;
        case SCR_QUICK:     show_quick(); break;
        case SCR_SETTINGS:  show_settings(); break;
        case SCR_BRIGHTNESS:show_brightness(); break;
        case SCR_ABOUT:     show_about(); break;
        case SCR_SYSINFO:   show_sysinfo(); break;
        case SCR_POWER:     show_power(); break;
        case SCR_FACES:     show_faces(); break;
        default: break;
    }
}

/* =========================================================
 * PUBLIC API
 * ========================================================= */
void ui_init(void)
{
    s_root = lv_scr_act();
    lv_obj_set_style_bg_color(s_root, C_BG, 0);
    lv_obj_add_event_cb(s_root, (lv_event_cb_t)ui_note_activity, LV_EVENT_PRESSED, NULL);
    ui_note_activity();
}
void ui_note_activity(void) { s_last_touch_ms = (uint32_t)(esp_timer_get_time() / 1000); }
bool ui_idle_timed_out(void)
{
    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
    return (now - s_last_touch_ms) > (uint32_t)g_set.timeout_s * 1000;
}
void ui_tick(void)
{
    if (s_cur == SCR_BOOT) { /* main.c switches us to SCR_WATCHFACE after boot delay */ }
}

/* main.c calls this once, after boot animation, to enter the live UI */
void ui_enter_watchface(void) { goto_screen(SCR_WATCHFACE); }
