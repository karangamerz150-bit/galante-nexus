#include "bsp.h"
#include "board_pins.h"
#include "settings.h"
#include "steps.h"
#include "hr_spo2.h"
#include "esp_log.h"
#include "esp_check.h"
#include "driver/spi_master.h"
#include "driver/ledc.h"
#include "driver/gpio.h"
#include "driver/rtc_io.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_vendor.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_touch_cst816s.h"
#include "esp_lvgl_port.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"
#include "esp_sleep.h"

static const char *TAG = "bsp";
i2c_master_bus_handle_t g_i2c;
static esp_lcd_panel_handle_t s_panel;
static adc_oneshot_unit_handle_t s_adc;
static adc_cali_handle_t s_cali;
static sdmmc_card_t *s_card;
static bool s_bl_ready;

i2c_master_dev_handle_t bsp_i2c_dev(uint8_t addr)
{
    i2c_device_config_t c = { .dev_addr_length = I2C_ADDR_BIT_LEN_7, .device_address = addr, .scl_speed_hz = 400000 };
    i2c_master_dev_handle_t d = NULL;
    return i2c_master_bus_add_device(g_i2c, &c, &d) == ESP_OK ? d : NULL;
}
bool bsp_i2c_probe(uint8_t addr) { return i2c_master_probe(g_i2c, addr, 50) == ESP_OK; }

void bsp_backlight(int pct)
{
    if (!s_bl_ready) return;
    if (pct < 0) pct = 0; if (pct > 100) pct = 100;
    uint32_t duty = (uint32_t)(pct * pct * 1023 / 10000);   /* gamma-ish curve */
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
}

void bsp_screen(bool on)
{
    if (on) { esp_lcd_panel_disp_on_off(s_panel, true); bsp_backlight(g_set.brightness); }
    else    { bsp_backlight(0); esp_lcd_panel_disp_on_off(s_panel, false); }
}

static void backlight_init(void)
{
    ledc_timer_config_t t = { .speed_mode = LEDC_LOW_SPEED_MODE, .duty_resolution = LEDC_TIMER_10_BIT,
                              .timer_num = LEDC_TIMER_0, .freq_hz = 5000, .clk_cfg = LEDC_AUTO_CLK };
    ledc_timer_config(&t);
    ledc_channel_config_t c = { .gpio_num = PIN_LCD_BL, .speed_mode = LEDC_LOW_SPEED_MODE,
                                .channel = LEDC_CHANNEL_0, .timer_sel = LEDC_TIMER_0, .duty = 0, .hpoint = 0 };
    ledc_channel_config(&c);
    s_bl_ready = true;
}

static void battery_init(void)
{
    adc_oneshot_unit_init_cfg_t u = { .unit_id = ADC_UNIT_1 };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&u, &s_adc));
    adc_oneshot_chan_cfg_t cc = { .atten = ADC_ATTEN_DB_12, .bitwidth = ADC_BITWIDTH_DEFAULT };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(s_adc, ADC_CHANNEL_4, &cc));   /* GPIO5 */
    adc_cali_curve_fitting_config_t cf = { .unit_id = ADC_UNIT_1, .chan = ADC_CHANNEL_4,
                                           .atten = ADC_ATTEN_DB_12, .bitwidth = ADC_BITWIDTH_DEFAULT };
    if (adc_cali_create_scheme_curve_fitting(&cf, &s_cali) != ESP_OK) s_cali = NULL;
}

int bsp_battery_mv(void)
{
    if (!s_adc || !s_cali) return -1;
    int sum = 0, n = 0, raw, mv;
    for (int i = 0; i < 16; i++) {
        if (adc_oneshot_read(s_adc, ADC_CHANNEL_4, &raw) == ESP_OK &&
            adc_cali_raw_to_voltage(s_cali, raw, &mv) == ESP_OK) { sum += mv; n++; }
    }
    return n ? (sum / n) * 3 : -1;
}

int bsp_battery_pct(void)
{
    static const struct { int mv, pct; } lut[] = { {4150,100},{4000,85},{3900,70},{3800,50},{3700,30},{3600,15},{3500,5},{3300,0} };
    int mv = bsp_battery_mv();
    if (mv < 0) return -1;
    if (mv >= lut[0].mv) return 100;
    for (int i = 1; i < 8; i++)
        if (mv >= lut[i].mv)
            return lut[i].pct + (lut[i-1].pct - lut[i].pct) * (mv - lut[i].mv) / (lut[i-1].mv - lut[i].mv);
    return 0;
}

static void sd_init(void)
{
    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = LCD_SPI_HOST;
    host.max_freq_khz = 20000;
    sdspi_device_config_t sc = SDSPI_DEVICE_CONFIG_DEFAULT();
    sc.gpio_cs = PIN_SD_CS;
    sc.host_id = LCD_SPI_HOST;
    esp_vfs_fat_mount_config_t mc = { .format_if_mount_failed = false, .max_files = 4, .allocation_unit_size = 16 * 1024 };
    if (esp_vfs_fat_sdspi_mount("/sdcard", &host, &sc, &mc, &s_card) != ESP_OK) { s_card = NULL; ESP_LOGW(TAG, "no SD card"); }
}

bool bsp_sd_info(uint32_t *size_mb)
{
    if (!s_card) return false;
    if (size_mb) *size_mb = (uint32_t)(((uint64_t)s_card->csd.capacity * s_card->csd.sector_size) >> 20);
    return true;
}

void bsp_init(void)
{
    i2c_master_bus_config_t ic = { .i2c_port = I2C_NUM_0, .sda_io_num = PIN_I2C_SDA, .scl_io_num = PIN_I2C_SCL,
                                   .clk_source = I2C_CLK_SRC_DEFAULT, .glitch_ignore_cnt = 7,
                                   .flags.enable_internal_pullup = true };
    ESP_ERROR_CHECK(i2c_new_master_bus(&ic, &g_i2c));
    backlight_init();
    battery_init();

    spi_bus_config_t bus = { .mosi_io_num = PIN_LCD_MOSI, .miso_io_num = PIN_SPI_MISO, .sclk_io_num = PIN_LCD_SCLK,
                             .quadwp_io_num = -1, .quadhd_io_num = -1, .max_transfer_sz = LCD_W * 40 * 2 };
    ESP_ERROR_CHECK(spi_bus_initialize(LCD_SPI_HOST, &bus, SPI_DMA_CH_AUTO));

    esp_lcd_panel_io_handle_t io;
    esp_lcd_panel_io_spi_config_t iocfg = { .dc_gpio_num = PIN_LCD_DC, .cs_gpio_num = PIN_LCD_CS,
        .pclk_hz = 40 * 1000 * 1000, .lcd_cmd_bits = 8, .lcd_param_bits = 8, .spi_mode = 0, .trans_queue_depth = 10 };
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)LCD_SPI_HOST, &iocfg, &io));
    esp_lcd_panel_dev_config_t pc = { .reset_gpio_num = PIN_LCD_RST,
        .rgb_ele_order = LCD_BGR_ORDER ? LCD_RGB_ELEMENT_ORDER_BGR : LCD_RGB_ELEMENT_ORDER_RGB, .bits_per_pixel = 16 };
    ESP_ERROR_CHECK(esp_lcd_new_panel_st7789(io, &pc, &s_panel));
    esp_lcd_panel_reset(s_panel);
    esp_lcd_panel_init(s_panel);
    esp_lcd_panel_invert_color(s_panel, LCD_INVERT_COLORS);
    esp_lcd_panel_disp_on_off(s_panel, true);

    const lvgl_port_cfg_t lc = ESP_LVGL_PORT_INIT_CONFIG();
    ESP_ERROR_CHECK(lvgl_port_init(&lc));
    const lvgl_port_display_cfg_t dc = {
        .io_handle = io, .panel_handle = s_panel,
        .buffer_size = LCD_W * 40, .double_buffer = true,
        .hres = LCD_W, .vres = LCD_H, .monochrome = false,
        .color_format = LV_COLOR_FORMAT_RGB565,
        .rotation = { .swap_xy = LCD_SWAP_XY, .mirror_x = LCD_MIRROR_X, .mirror_y = LCD_MIRROR_Y },
        .flags = { .buff_dma = true, .swap_bytes = true } };
    lv_display_t *disp = lvgl_port_add_disp(&dc);

    vTaskDelay(pdMS_TO_TICKS(60));   /* touch shares the reset line with the LCD */
    esp_lcd_panel_io_handle_t tio;
    esp_lcd_panel_io_i2c_config_t tcfg = ESP_LCD_TOUCH_IO_I2C_CST816S_CONFIG();
    tcfg.scl_speed_hz = 400000;
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_i2c(g_i2c, &tcfg, &tio));
    esp_lcd_touch_config_t tc = { .x_max = 240, .y_max = 320, .rst_gpio_num = -1, .int_gpio_num = PIN_TP_INT,
        .levels = { .reset = 0, .interrupt = 0 },
        .flags = { .swap_xy = TOUCH_SWAP_XY, .mirror_x = TOUCH_MIRROR_X, .mirror_y = TOUCH_MIRROR_Y } };
    esp_lcd_touch_handle_t tp;
    ESP_ERROR_CHECK(esp_lcd_touch_new_i2c_cst816s(tio, &tc, &tp));
    const lvgl_port_touch_cfg_t tch = { .disp = disp, .handle = tp };
    lvgl_port_add_touch(&tch);

    sd_init();
}

void bsp_deep_sleep(void)
{
    hr_stop();
    steps_save_now();
    settings_save();
    settings_time_save();
    bsp_backlight(0);
    esp_lcd_panel_disp_on_off(s_panel, false);
    rtc_gpio_pullup_en(PIN_WAKE);
    esp_sleep_enable_ext0_wakeup(PIN_WAKE, 0);   /* BOOT key wakes (full reboot) */
    esp_deep_sleep_start();
}
