#pragma once
#include <stdint.h>
void steps_init(void);
void steps_feed(float ax, float ay, float az, uint32_t now_ms);
uint32_t steps_today(void);
void steps_get_history(uint32_t *out7, int n);   /* last n days, [0]=today */
void steps_save_now(void);
