#include <stddef.h>
#include <time.h>
#include <sys/time.h>
#include "settings.h"
#include "nvs.h"

settings_t g_set = { .brightness = 70, .timeout_s = 30, .face = 0, .ble_on = true, .night = false };
#define NS "nexus"

uint32_t nv_get_u32(const char *k, uint32_t def)
{
    nvs_handle_t h; uint32_t v = def;
    if (nvs_open(NS, NVS_READONLY, &h) == ESP_OK) { nvs_get_u32(h, k, &v); nvs_close(h); }
    return v;
}
void nv_set_u32(const char *k, uint32_t v)
{
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READWRITE, &h) == ESP_OK) { nvs_set_u32(h, k, v); nvs_commit(h); nvs_close(h); }
}
bool nv_get_blob(const char *k, void *buf, size_t len)
{
    nvs_handle_t h; size_t n = len; bool ok = false;
    if (nvs_open(NS, NVS_READONLY, &h) == ESP_OK) { ok = nvs_get_blob(h, k, buf, &n) == ESP_OK && n == len; nvs_close(h); }
    return ok;
}
void nv_set_blob(const char *k, const void *buf, size_t len)
{
    nvs_handle_t h;
    if (nvs_open(NS, NVS_READWRITE, &h) == ESP_OK) { nvs_set_blob(h, k, buf, len); nvs_commit(h); nvs_close(h); }
}
void settings_load(void)
{
    g_set.brightness = nv_get_u32("bright", g_set.brightness);
    g_set.timeout_s  = nv_get_u32("timeout", g_set.timeout_s);
    g_set.face       = nv_get_u32("face", g_set.face);
    g_set.ble_on     = nv_get_u32("ble", g_set.ble_on);
    g_set.night      = nv_get_u32("night", g_set.night);
}
void settings_save(void)
{
    nv_set_u32("bright", g_set.brightness); nv_set_u32("timeout", g_set.timeout_s);
    nv_set_u32("face", g_set.face); nv_set_u32("ble", g_set.ble_on); nv_set_u32("night", g_set.night);
}
bool settings_time_valid(void) { return time(NULL) > 1700000000; }
void settings_time_save(void) { if (settings_time_valid()) nv_set_u32("lasttime", (uint32_t)time(NULL)); }
void settings_time_restore(void)
{
    uint32_t t = nv_get_u32("lasttime", 0);
    if (t > 1700000000) { struct timeval tv = { .tv_sec = t }; settimeofday(&tv, NULL); }
}
