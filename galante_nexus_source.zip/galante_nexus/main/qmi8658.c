/* QMI8658C 6-axis IMU driver (register-level, I2C).
 * Register map per QMI8658C datasheet rev 1.0. Address 0x6B when SA0 low
 * (Waveshare board ties SA0 low -> 0x6B; some boards use 0x6A -- probed). */
#include "qmi8658.h"
#include "bsp.h"
#include "esp_log.h"
#include "driver/i2c_master.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define REG_WHO_AM_I   0x00
#define REG_RESET      0x60
#define REG_CTRL1      0x02
#define REG_CTRL2      0x03   /* accel ODR/range */
#define REG_CTRL3      0x04   /* gyro ODR/range */
#define REG_CTRL7      0x08   /* enable accel/gyro */
#define REG_AX_L       0x35
#define REG_TEMP_L     0x33
#define WHOAMI_VAL     0x05

static i2c_master_dev_handle_t s_dev;
static uint8_t s_addr;
static const char *TAG = "qmi8658";

static bool reg_write(uint8_t reg, uint8_t val)
{
    uint8_t buf[2] = { reg, val };
    return i2c_master_transmit(s_dev, buf, 2, 100) == ESP_OK;
}
static bool reg_read(uint8_t reg, uint8_t *buf, size_t n)
{
    return i2c_master_transmit_receive(s_dev, &reg, 1, buf, n, 100) == ESP_OK;
}

bool qmi_init(void)
{
    if (bsp_i2c_probe(0x6B)) s_addr = 0x6B;
    else if (bsp_i2c_probe(0x6A)) s_addr = 0x6A;
    else { ESP_LOGE(TAG, "QMI8658 not found on I2C bus"); return false; }
    s_dev = bsp_i2c_dev(s_addr);
    if (!s_dev) return false;

    uint8_t who = 0;
    if (!reg_read(REG_WHO_AM_I, &who, 1) || who != WHOAMI_VAL) {
        ESP_LOGE(TAG, "bad WHO_AM_I 0x%02X", who);
        return false;
    }
    reg_write(REG_RESET, 0xB0);
    vTaskDelay(pdMS_TO_TICKS(15));
    reg_write(REG_CTRL1, 0x60);        /* auto-increment addr, internal 2MHz osc */
    reg_write(REG_CTRL2, 0x04 | 0x00); /* accel +/-4g, 250Hz ODR */
    reg_write(REG_CTRL3, 0x64);        /* gyro +/-512dps, 250Hz ODR */
    reg_write(REG_CTRL7, 0x03);        /* enable accel + gyro */
    ESP_LOGI(TAG, "QMI8658 ready at 0x%02X", s_addr);
    return true;
}

void qmi_sleep(bool low_power)
{
    if (low_power) { reg_write(REG_CTRL7, 0x01); reg_write(REG_CTRL2, 0x04 | 0x03); }  /* accel-only, low ODR */
    else           { reg_write(REG_CTRL2, 0x04 | 0x00); reg_write(REG_CTRL7, 0x03); }
}

bool qmi_read(qmi_sample_t *s)
{
    uint8_t raw[14];
    if (!reg_read(REG_TEMP_L, raw, 14)) return false;
    int16_t temp = (int16_t)(raw[1] << 8 | raw[0]);
    int16_t ax = (int16_t)(raw[3] << 8 | raw[2]);
    int16_t ay = (int16_t)(raw[5] << 8 | raw[4]);
    int16_t az = (int16_t)(raw[7] << 8 | raw[6]);
    int16_t gx = (int16_t)(raw[9] << 8 | raw[8]);
    int16_t gy = (int16_t)(raw[11] << 8 | raw[10]);
    int16_t gz = (int16_t)(raw[13] << 8 | raw[12]);
    const float acc_lsb = 8192.0f;   /* 1g @ +/-4g range */
    const float gyr_lsb = 64.0f;     /* 1dps @ +/-512dps range */
    s->ax = ax / acc_lsb; s->ay = ay / acc_lsb; s->az = az / acc_lsb;
    s->gx = gx / gyr_lsb; s->gy = gy / gyr_lsb; s->gz = gz / gyr_lsb;
    s->temp_c = temp / 256.0f;
    return true;
}
