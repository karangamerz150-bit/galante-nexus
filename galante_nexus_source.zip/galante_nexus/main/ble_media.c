/*
 * Bluetooth media control, real and standalone.
 *
 * HARDWARE REALITY CHECK (please read):
 * The ESP32-S3 radio is BLE-only -- it has no Classic Bluetooth (BR/EDR)
 * radio. AVRCP (the profile phones normally use for a "Now Playing" title
 * and rich transport control) is a Classic-BT profile and physically
 * cannot run on this chip. So instead this implements the thing that
 * *does* work over BLE and needs zero companion app on either side:
 * GALANTE advertises as a standard BLE HID "Consumer Control" device
 * (the same class of device as a BLE presenter clicker or earbud touch
 * controls). iOS and Android both natively recognize HID Consumer
 * Control usages for Play/Pause, Next/Previous Track and Volume Up/Down
 * and route them to whatever media app is currently playing on the
 * phone -- exactly like a Bluetooth headset's inline remote.
 *
 * Trade-off, stated plainly: because there is no AVRCP link, GALANTE
 * cannot pull back the track title/artist or the phone's playback
 * state. The UI must not invent a "Now Playing" string -- it only shows
 * the BLE connection state (Disconnected / Pairing / Connected) plus
 * confirmation that a button press was sent, never a fake song name.
 *
 * Uses NimBLE (ESP-IDF component). Bonded, encrypted link required
 * before HID reports are accepted (BLE HID security requirement on
 * both iOS and Android).
 */
#include "ble_media.h"
#include "esp_log.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_uuid.h"
#include "host/util/util.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
#include "store/config/ble_store_config.h"
#include <string.h>

static const char *TAG = "ble_media";
static uint16_t s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
static uint16_t s_hid_report_handle;
static bool s_notify_enabled;

/* Standard HID Consumer-Control report descriptor: one 16-bit usage
 * per report, values from the USB HID Usage Tables (Consumer page 0x0C). */
static const uint8_t hid_report_map[] = {
    0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x01,
    0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03,
    0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
    0xC0
};
#define USAGE_PLAY_PAUSE 0x00CD
#define USAGE_NEXT_TRACK 0x00B5
#define USAGE_PREV_TRACK 0x00B6
#define USAGE_VOL_UP     0x00E9
#define USAGE_VOL_DOWN   0x00EA

static int gatt_access_cb(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg);

static const struct ble_gatt_svc_def gatt_svcs[] = {
    { .type = BLE_GATT_SVC_TYPE_PRIMARY,
      .uuid = BLE_UUID16_DECLARE(0x1812),   /* HID Service */
      .characteristics = (struct ble_gatt_chr_def[]) {
        { .uuid = BLE_UUID16_DECLARE(0x2A4B), .access_cb = gatt_access_cb, .flags = BLE_GATT_CHR_F_READ },        /* Report Map */
        { .uuid = BLE_UUID16_DECLARE(0x2A4A), .access_cb = gatt_access_cb, .flags = BLE_GATT_CHR_F_READ },        /* HID Info */
        { .uuid = BLE_UUID16_DECLARE(0x2A4C), .access_cb = gatt_access_cb, .flags = BLE_GATT_CHR_F_WRITE_NO_RSP },/* Control Point */
        { .uuid = BLE_UUID16_DECLARE(0x2A4D), .access_cb = gatt_access_cb,
          .flags = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_NOTIFY, .val_handle = &s_hid_report_handle },             /* Input Report */
        { 0 } } },
    { 0 }
};

static int gatt_access_cb(uint16_t conn, uint16_t attr, struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    if (ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR) {
        uint16_t uuid = ble_uuid_u16(ctxt->chr->uuid);
        if (uuid == 0x2A4B) os_mbuf_append(ctxt->om, hid_report_map, sizeof(hid_report_map));
        else if (uuid == 0x2A4A) { uint8_t info[4] = {0x11,0x01,0x00,0x02}; os_mbuf_append(ctxt->om, info, 4); }
    }
    return 0;
}

static void send_usage(uint16_t usage)
{
    if (s_conn_handle == BLE_HS_CONN_HANDLE_NONE || !s_notify_enabled) {
        ESP_LOGW(TAG, "not connected/subscribed, dropping key");
        return;
    }
    uint8_t rpt[2] = { (uint8_t)(usage & 0xFF), (uint8_t)(usage >> 8) };
    struct os_mbuf *om = ble_hs_mbuf_from_flat(rpt, 2);
    ble_gattc_notify_custom(s_conn_handle, s_hid_report_handle, om);
    uint8_t zero[2] = {0,0};
    struct os_mbuf *om2 = ble_hs_mbuf_from_flat(zero, 2);
    ble_gattc_notify_custom(s_conn_handle, s_hid_report_handle, om2);   /* key-up */
}

void ble_media_play_pause(void) { send_usage(USAGE_PLAY_PAUSE); }
void ble_media_next(void)       { send_usage(USAGE_NEXT_TRACK); }
void ble_media_prev(void)       { send_usage(USAGE_PREV_TRACK); }
void ble_media_vol_up(void)     { send_usage(USAGE_VOL_UP); }
void ble_media_vol_down(void)   { send_usage(USAGE_VOL_DOWN); }
bool ble_media_connected(void)  { return s_conn_handle != BLE_HS_CONN_HANDLE_NONE; }

static void start_advertising(void);

static int gap_event_cb(struct ble_gap_event *ev, void *arg)
{
    switch (ev->type) {
    case BLE_GAP_EVENT_CONNECT:
        if (ev->connect.status == 0) s_conn_handle = ev->connect.conn_handle;
        else start_advertising();
        break;
    case BLE_GAP_EVENT_DISCONNECT:
        s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
        s_notify_enabled = false;
        start_advertising();
        break;
    case BLE_GAP_EVENT_SUBSCRIBE:
        s_notify_enabled = ev->subscribe.cur_notify;
        break;
    case BLE_GAP_EVENT_REPEAT_PAIRING: {
        struct ble_gap_conn_desc desc;
        ble_gap_conn_find(ev->repeat_pairing.conn_handle, &desc);
        ble_store_util_delete_peer(&desc.peer_id_addr);
        return BLE_GAP_REPEAT_PAIRING_RETRY;
    }
    default: break;
    }
    return 0;
}

static void start_advertising(void)
{
    struct ble_hs_adv_fields fields = {0};
    const char name[] = "GALANTE";
    fields.name = (uint8_t *)name; fields.name_len = sizeof(name) - 1; fields.name_is_complete = 1;
    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    uint16_t appearance = 0x03C1;  /* HID Keyboard-class appearance, closest to a media remote */
    fields.appearance = appearance; fields.appearance_is_present = 1;
    uint16_t uuid16 = 0x1812;
    fields.uuids16 = (ble_uuid16_t[]){ BLE_UUID16_INIT(uuid16) }; fields.num_uuids16 = 1; fields.uuids16_is_complete = 1;
    ble_gap_adv_set_fields(&fields);

    struct ble_gap_adv_params adv = {0};
    adv.conn_mode = BLE_GAP_CONN_MODE_UND;
    adv.disc_mode = BLE_GAP_DISC_MODE_GEN;
    ble_gap_adv_start(BLE_OWN_ADDR_PUBLIC, NULL, BLE_HS_FOREVER, &adv, gap_event_cb, NULL);
}

static void on_sync(void)
{
    ble_hs_util_ensure_addr(0);
    ble_svc_gap_device_name_set("GALANTE");
    start_advertising();
}

static void host_task(void *param) { nimble_port_run(); }

void ble_media_init(void)
{
    nimble_port_init();
    ble_svc_gap_init();
    ble_svc_gatt_init();
    ble_gatts_count_cfg(gatt_svcs);
    ble_gatts_add_svcs(gatt_svcs);

    ble_hs_cfg.sm_io_cap = BLE_SM_IO_CAP_NO_IO;
    ble_hs_cfg.sm_bonding = 1;
    ble_hs_cfg.sm_mitm = 0;
    ble_hs_cfg.sm_sc = 1;
    ble_hs_cfg.sm_our_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.sm_their_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.sync_cb = on_sync;
    ble_store_config_init();

    nimble_port_freertos_init(host_task);
    ESP_LOGI(TAG, "advertising as BLE HID Consumer Control (GALANTE)");
}
