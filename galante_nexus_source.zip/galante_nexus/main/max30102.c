/* MAX30102 register-level driver for GALANTE NEXUS. */
#include "max30102.h"
#include "bsp.h"
#include "board_pins.h"
#include "esp_log.h"
#include "driver/i2c_master.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define REG_FIFO_WR      0x04
#define REG_FIFO_RD      0x06
#define REG_FIFO_DATA    0x07
#define REG_FIFO_CFG     0x08
#define REG_MODE_CFG     0x09
#define REG_SPO2_CFG     0x0A
#define REG_LED1_PA      0x0C
#define REG_LED2_PA      0x0D
#define REG_PART_ID      0xFF

static i2c_master_dev_handle_t s_dev;
static bool s_ready;
static const char *TAG = "max30102";

static bool w(uint8_t reg, uint8_t val) { uint8_t b[2] = {reg,val}; return i2c_master_transmit(s_dev,b,2,100)==ESP_OK; }
static bool r(uint8_t reg, uint8_t *buf, size_t n) { return i2c_master_transmit_receive(s_dev,&reg,1,buf,n,100)==ESP_OK; }

bool max30102_init(void)
{
    s_ready = false;
    if (!bsp_i2c_probe(I2C_ADDR_MAX30102)) { ESP_LOGW(TAG,"MAX30102 not found"); return false; }
    s_dev = bsp_i2c_dev(I2C_ADDR_MAX30102);
    if (!s_dev) return false;
    uint8_t id=0;
    if (!r(REG_PART_ID,&id,1) || id != 0x15) { ESP_LOGW(TAG,"MAX30102 PART_ID invalid: 0x%02X",id); s_dev=NULL; return false; }
    if (!w(REG_MODE_CFG,0x40)) return false;
    vTaskDelay(pdMS_TO_TICKS(10));
    /* FIFO: average 4 samples, rollover enabled. */
    if (!w(REG_FIFO_CFG,0x4F)) return false;
    /* SpO2 mode, 100 samples/s, 411us pulse, 18-bit ADC. */
    if (!w(REG_MODE_CFG,0x03) || !w(REG_SPO2_CFG,0x27)) return false;
    /* Conservative LED current for a wrist/finger prototype. */
    if (!w(REG_LED1_PA,0x24) || !w(REG_LED2_PA,0x24)) return false;
    w(REG_FIFO_WR,0x00); w(REG_FIFO_RD,0x00);
    s_ready=true;
    ESP_LOGI(TAG,"MAX30102 ready");
    return true;
}

bool max30102_is_ready(void) { return s_ready && s_dev != NULL; }

void max30102_shutdown(bool shut)
{
    if (!max30102_is_ready()) return;
    uint8_t cfg=0;
    if (!r(REG_MODE_CFG,&cfg,1)) return;
    if (shut) cfg |= 0x80; else cfg &= (uint8_t)~0x80;
    w(REG_MODE_CFG,cfg);
}

bool max30102_read(uint32_t *ir, uint32_t *red)
{
    if (!max30102_is_ready() || !ir || !red) return false;
    uint8_t wr=0,rd=0;
    if (!r(REG_FIFO_WR,&wr,1) || !r(REG_FIFO_RD,&rd,1) || wr==rd) return false;
    uint8_t d[6];
    if (!r(REG_FIFO_DATA,d,6)) return false;
    *red=((uint32_t)(d[0]&0x03)<<16)|((uint32_t)d[1]<<8)|d[2];
    *ir =((uint32_t)(d[3]&0x03)<<16)|((uint32_t)d[4]<<8)|d[5];
    return true;
}
