#pragma once
/* Waveshare ESP32-S3-Touch-LCD-2 (ST7789T3 + CST816D + QMI8658).
 * Every GPIO below was read from the net names in Waveshare's official
 * schematic PDF (ESP32-S3-Touch-LCD-2-SchDoc.pdf). Re-check against your board revision. */
#define PIN_LCD_MOSI   38   /* shared with SD_MOSI */
#define PIN_LCD_SCLK   39   /* shared with SD_SCLK */
#define PIN_SPI_MISO   40   /* SD_MISO (LCD has no MISO) */
#define PIN_LCD_DC     42
#define PIN_LCD_CS     45
#define PIN_LCD_RST     0   /* same net as BOOT key; touch reset is on this net too */
#define PIN_LCD_BL      1   /* NPN-switched backlight, HIGH = on */
#define PIN_SD_CS      41   /* SD is SPI-mode on the SAME bus as the LCD */
#define PIN_I2C_SDA    48   /* touch + QMI8658 (+ MAX30102 you add) */
#define PIN_I2C_SCL    47
#define PIN_TP_INT     46
#define PIN_IMU_INT1    3
#define PIN_BAT_ADC     5   /* ADC1_CH4, divider 200k/100k => Vbat = 3 x Vadc */
#define PIN_WAKE        0   /* BOOT key, RTC-capable, deep-sleep wake */

#define LCD_W 320
#define LCD_H 240
#define LCD_SPI_HOST  SPI2_HOST
#define I2C_ADDR_TOUCH   0x15   /* CST816D */
#define I2C_ADDR_MAX30102 0x57

/* Orientation: tune these on first boot if the image/touch is mirrored or rotated. */
#define LCD_SWAP_XY   1
#define LCD_MIRROR_X  1
#define LCD_MIRROR_Y  0
#define TOUCH_SWAP_XY  1
#define TOUCH_MIRROR_X 1
#define TOUCH_MIRROR_Y 0
#define LCD_INVERT_COLORS 1
#define LCD_BGR_ORDER     0
