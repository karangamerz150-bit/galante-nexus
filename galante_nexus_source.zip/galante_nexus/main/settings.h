#pragma once
#include <stdbool.h>
#include <stdint.h>
typedef struct { uint8_t brightness; uint16_t timeout_s; uint8_t face; bool ble_on; bool night; } settings_t;
extern settings_t g_set;
void settings_load(void);
void settings_save(void);
uint32_t nv_get_u32(const char *key, uint32_t def);
void nv_set_u32(const char *key, uint32_t v);
bool nv_get_blob(const char *key, void *buf, size_t len);
void nv_set_blob(const char *key, const void *buf, size_t len);
bool settings_time_valid(void);
void settings_time_save(void);
void settings_time_restore(void);
