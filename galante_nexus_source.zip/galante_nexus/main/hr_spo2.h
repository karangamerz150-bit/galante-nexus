#pragma once
#include <stdbool.h>
#include <stdint.h>
typedef enum { HR_SENSOR_MISSING, HR_NO_CONTACT, HR_WARMING_UP, HR_MEASURING, HR_OK } hr_state_t;
void hr_init(void);
void hr_start(void);
void hr_stop(void);
void hr_task_tick(void);
hr_state_t hr_get(int *bpm_out, int *spo2_out);
