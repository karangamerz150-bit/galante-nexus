# Build + flash GALANTE NEXUS using only an Android phone

The ZIP contains the ESP-IDF source, not a precompiled firmware binary. A source project cannot be flashed directly; it must first be compiled for ESP32-S3.

## 1. Build in the cloud

1. Create/open a GitHub repository on your phone.
2. Upload the contents of this project.
3. Open **Actions** and run **Build GALANTE NEXUS** manually.
4. When it finishes successfully, open the workflow run and download the artifact named `GALANTE-NEXUS-ESP32-S3-firmware`.
5. The artifact contains the bootloader, partition table, app binary, flash arguments, and—when the merge tool is available—a single `galante_nexus_merged.bin`.

## 2. Flash from Android over USB OTG

Use an Android ESP32 flasher that supports ESP32-S3 and USB OTG. The current Play Store listing for `ESP32_Flasher` states that it supports ESP32-S3 over Android USB/OTG and can flash bootloader, partition and firmware binaries at specified offsets. Another current Android flasher, `ESPFlash-ESP32/ESP8266Flasher`, also advertises ESP32-S3 USB-OTG flashing.

Use the exact offsets from the generated `flash_args` file. Do not guess offsets.

If the merged binary is present and the flasher supports a single merged image at offset `0x0`, that is the simplest option.

## 3. Put the Waveshare board in download mode

- Connect the board to the Android phone with a USB-C OTG connection.
- Hold **BOOT**.
- Press **RESET** once.
- Release **BOOT**.
- Grant Android USB permission to the flasher.
- Select the firmware and flash it.
- When finished, press RESET.

Waveshare documents the same BOOT/download-mode procedure when automatic download mode is not entered. The board's USB-C port is its programming/debug interface.

## 4. First boot

For the first test, use USB power. Confirm:

1. GALANTE powered by NEXUS boot screen
2. 320x240 landscape display
3. Touch
4. Watch face
5. Swipe between faces
6. QMI8658 steps
7. MAX30102 detection/HR/SpO2 screen
8. Bluetooth media controls

Do not attach or modify the LiPo wiring while doing the first firmware test.
